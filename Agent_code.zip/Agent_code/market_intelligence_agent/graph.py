import os
import ssl
import urllib3
# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# Disable SSL verification via environment
os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["CURL_CA_BUNDLE"] = ""
os.environ["REQUESTS_CA_BUNDLE"] = ""
# Disable default SSL context
ssl._create_default_https_context = ssl._create_unverified_context
# Patch requests globally
import requests
from requests.adapters import HTTPAdapter
class NoSSLVerifyAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        kwargs["cert_reqs"] = ssl.CERT_NONE
        kwargs["assert_hostname"] = False
        return super().init_poolmanager(*args, **kwargs)
_original_session_init = requests.Session.__init__
def patched_session_init(self, *args, **kwargs):
    _original_session_init(self, *args, **kwargs)
    self.verify = False
    self.mount("https://", NoSSLVerifyAdapter())
    self.mount("http://", NoSSLVerifyAdapter())
requests.Session.__init__ = patched_session_init

from typing import Dict, List, Callable, Annotated
from langgraph.graph import StateGraph, END
from langchain_core.messages import SystemMessage, HumanMessage
from fastapi.encoders import jsonable_encoder
from tavily import TavilyClient
from app.core.deps import get_llm_client_agent
# from .tools.proprietary_tools import get_proprietary_tools_for_sources
# from .tools.thirdparty_tools import get_third_party_tools_for_sources
from .prompt import PROPRIETARY_AGENT_PROMPT, THIRD_PARTY_AGENT_PROMPT
from .schema import ResearchSignals, GraphState
from .market_intelligence import get_market
from app.core.config import config

# =========================================================
# 1. CLIENTS
# =========================================================

llm = get_llm_client_agent()
tavily = TavilyClient(api_key=config.TAVILY_API_KEY)

# =========================================================
# 2. SYSTEM PROMPT
# =========================================================

SYSTEM_PROMPT = """
You are a market intelligence research agent.

TASK:
Extract STRUCTURED market intelligence signals.

RULES:
- Output MUST follow the schema exactly
- No prose or explanations
- Best-effort, factual, professional intelligence
"""


# =========================================================
# 3. LLM CALL
# =========================================================

def call_llm(prompt: str) -> ResearchSignals:
    structured_llm = llm.with_structured_output(ResearchSignals)
    return structured_llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=prompt),
        ]
    )


# =========================================================
# 4. PROMPT BUILDERS
# =========================================================

def pwc_document_prompt(input_data: dict) -> str:
    pwc = input_data["pwc_content"]
    return f"""
Analyze the following internal document and extract market intelligence.

DOCUMENT:
{pwc["supportingDoc"]}

INSTRUCTIONS:
{pwc.get("supportingDoc_instructions", "")}
"""


def generic_tool_prompt(tool_name: str, input_data: dict) -> str:
    return f"""
SOURCE: {tool_name}
TOPIC: {input_data.get("research_topics")}
GUIDELINES: {input_data.get("research_guidelines")}
"""


# =========================================================
# 5. GENERIC TOOL NODE (LLM-ONLY)
# =========================================================

def make_llm_tool_node(
    area: str,
    tool_name: str,
    prompt_builder: Callable[[dict], str],
):
    def node(state: GraphState) -> dict:
        signals = call_llm(prompt_builder(state.input))
        return {
            "tool_results": {
                area: {
                    tool_name: signals
                }
            }
        }

    return node
# =========================================================
# 6. PROPRIETARY_AGENT_TOOL NODE 
# =========================================================

def proprietary_tools_node(state: GraphState) -> dict:
    return




# =========================================================
# 7. TAVILY TOOL NODE (REAL EXTERNAL SEARCH)
# =========================================================

def tavily_tool_node(state: GraphState) -> dict:
    query = state.input.get("research_topics")
    guidelines = state.input.get("research_guidelines", "")

    response = tavily.search(
        query=query,
        search_depth="advanced",
        max_results=5,
    )

    contents = [
        r.get("content", "")
        for r in response.get("results", [])
        if r.get("content")
    ]

    prompt = f"""
Analyze the following external web research content.

GUIDELINES:
{guidelines}

CONTENT:
{chr(10).join(contents)}
"""

    signals = call_llm(prompt)

    return {
        "tool_results": {
            "externalResearch": {
                "tavily": signals
            }
        }
    }


# =========================================================
# 8. ROUTER
# =========================================================

def router_node(state: GraphState) -> dict:
    return {}


def router_decision(state: GraphState) -> List[str]:
    routes = []

    if state.input.get("pwc_content", {}).get("isSelected"):
        routes.append("pwc_document")

    if state.input.get("proprietary", {}).get("isSelected"):
        routes.append("proprietary")

    if state.input.get("thirdParty", {}).get("isSelected"):
        routes.append("thirdParty")

    if state.input.get("externalResearch", {}).get("isSelected"):
        routes.append("externalResearch")

    return routes


# =========================================================
# 9. BUILD GRAPH
# =========================================================

def build_graph():
    graph = StateGraph(GraphState)

    # Router
    graph.add_node("router", router_node)

    # PwC internal document
    graph.add_node(
        "pwc_document",
        make_llm_tool_node(
            "pwc_content",
            "document_llm",
            pwc_document_prompt,
        )
    )

    # Proprietary (placeholder: API-backed tools later)
    graph.add_node(
        "proprietary",
        make_llm_tool_node(
            "proprietary",
            "PwC Industry Edge",
            lambda inp: generic_tool_prompt("PwC Industry Edge", inp),
        )
    )

    # Third-party (placeholder: Factiva / Capital IQ APIs)
    graph.add_node(
        "thirdParty",
        make_llm_tool_node(
            "thirdParty",
            "Factiva",
            lambda inp: generic_tool_prompt("Factiva", inp),
        )
    )

    # External Research (REAL Tavily)
    graph.add_node("externalResearch", tavily_tool_node)

    # Entry
    graph.set_entry_point("router")

    # Conditional fan-out
    graph.add_conditional_edges(
        "router",
        router_decision,
        {
            "pwc_document": "pwc_document",
            "proprietary": "proprietary",
            "thirdParty": "thirdParty",
            "externalResearch": "externalResearch",
        },
    )

    # Fan-out ends
    graph.add_edge("pwc_document", END)
    graph.add_edge("proprietary", END)
    graph.add_edge("thirdParty", END)
    graph.add_edge("externalResearch", END)

    return graph.compile()



# Build once at module load
graph = build_graph()

def get_market_insights(input_data: dict) -> dict:
    result = graph.invoke(
        GraphState(input=input_data)
    )
    return jsonable_encoder(result.get("tool_results", {}))


if __name__ == "__main__":
    input_data = get_market()
    output = get_market_insights(input_data)
    print(output)

