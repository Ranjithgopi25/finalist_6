from langchain_core.tools import tool
from typing import Dict, List
import logging

logger = logging.getLogger(__name__)


@tool("PwC Industry Edge")
def search_pwc_industry_edge(query: str, guidelines: str = "") -> str:
    """
        Search PwC Industry Edge for industry-specific insights and data.
    """
    logger.info(f"[Tool: PwC Industry Edge]")
    return f"Research data from PwC Industry Edge for: {query}\nGuidelines: {guidelines}"

@tool("PwC Insights")
def search_pwc_insights(query: str, guidelines: str = "") -> str:
    """
        Search PwC Insights for research content.
    """
    logger.info(f"[Tool: PwC Insights] Query: {query}, Guidelines: {guidelines}")
    return f"Research data from PwC Insights for: {query}\nGuidelines: {guidelines}"


@tool("s+b Journal")
def search_sb_journal(query: str, guidelines: str = "") -> str:
    """
        Search s+b Journal for articles and insights.
    """
    logger.info(f"[Tool: s+b Journal]")
    return f"Research data from s+b Journal for: {query}\nGuidelines: {guidelines}"


@tool("Executive Leadership Hub")
def search_executive_leadership_hub(query: str, guidelines: str = "") -> str:
    """
        Search Executive Leadership Hub for leadership insights.
    """
    logger.info(f"[Tool: Executive Leadership Hub]")
    return f"Research data from Executive Leadership Hub for: {query}\nGuidelines: {guidelines}"


@tool("The Exchange")
def search_the_exchange(query: str, guidelines: str = "") -> str:
    """
        Search The Exchange for content.
    """
    logger.info(f"[Tool: The Exchange]")
    return f"Research data from The Exchange for: {query}\nGuidelines: {guidelines}"


@tool("PwC Connected Source")
def search_pwc_connected_source(query: str, guidelines: str = "") -> str:
    """
        Search PwC Connected Source for knowledge base content.
    """
    logger.info(f"[Tool: PwC Connected Source]")
    return f"Research data from PwC Connected Source for: {query}\nGuidelines: {guidelines}"


@tool("PwC Benchmarking")
def search_pwc_benchmarking(query: str, guidelines: str = "") -> str:
    """
        Search PwC Benchmarking for benchmarking data.
    """
    logger.info(f"[Tool: PwC Benchmarking]")
    return f"Research data from PwC Benchmarking for: {query}\nGuidelines: {guidelines}"


@tool("Insights Factory")
def search_insights_factory(query: str, guidelines: str = "") -> str:
    """
        Search Insights Factory for insights.
    """
    logger.info(f"[Tool: Insights Factory]")
    return f"Research data from Insights Factory for: {query}\nGuidelines: {guidelines}"


@tool("PwC Intelligence")
def search_pwc_intelligence(query: str, guidelines: str = "") -> str:
    """
        Search PwC Intelligence for intelligence data.
    """
    logger.info(f"[Tool: PwC Intelligence]")
    return f"Research data from PwC Intelligence for: {query}\nGuidelines: {guidelines}"


@tool("Client Success Stories")
def search_client_success_stories(query: str, guidelines: str = "") -> str:
    """
        Search Client Success Stories for case studies.
    """
    logger.info(f"[Tool: Client Success Stories]")
    return f"Research data from Client Success Stories for: {query}\nGuidelines: {guidelines}"


@tool("Inside Industries")
def search_inside_industries(query: str, guidelines: str = "") -> str:
    """
        Search Inside Industries for industry-specific content.
    """
    logger.info(f"[Tool: Inside Industries] Query: {query}, Guidelines: {guidelines}")
    return f"Research data from Inside Industries for: {query}\nGuidelines: {guidelines}"


@tool("Value Store")
def search_value_store(query: str, guidelines: str = "") -> str:
    """
        Search Value Store for content.
    """
    logger.info(f"[Tool: Value Store] Query: {query}, Guidelines: {guidelines}")
    return f"Research data from Value Store for: {query}\nGuidelines: {guidelines}"

# Mapping of source names (exact match from user selection) to tool functions
PROPRIETARY_TOOLS_MAP = {
    "PwC Industry Edge": search_pwc_industry_edge,
    "PwC Insights": search_pwc_insights,
    "s+b Journal": search_sb_journal,
    "Executive Leadership Hub": search_executive_leadership_hub,
    "The Exchange": search_the_exchange,
    "PwC Connected Source": search_pwc_connected_source,
    "PwC Benchmarking": search_pwc_benchmarking,
    "Insights Factory": search_insights_factory,
    "PwC Intelligence": search_pwc_intelligence,
    "Client Success Stories": search_client_success_stories,
    "Inside Industries": search_inside_industries,
    "Value Store": search_value_store,
}

