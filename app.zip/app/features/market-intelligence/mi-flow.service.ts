import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

/**
 * Market Intelligence Flow Service
 * Manages all flow states for Market Intelligence feature
 * Completely isolated from Thought Leadership and DDC services
 */
@Injectable({
  providedIn: 'root'
})
export class MiFlowService {
  private draftContentFlowOpen = new BehaviorSubject<boolean>(false);
  private conductResearchFlowOpen = new BehaviorSubject<boolean>(false);
  private editContentFlowOpen = new BehaviorSubject<boolean>(false);
  private formatTranslatorFlowOpen = new BehaviorSubject<boolean>(false);
  private generatePodcastFlowOpen = new BehaviorSubject<boolean>(false);
  private refineContentFlowOpen = new BehaviorSubject<boolean>(false);
  private brandFormatFlowOpen = new BehaviorSubject<boolean>(false);
  private professionalPolishFlowOpen = new BehaviorSubject<boolean>(false);

  draftContentFlow$ = this.draftContentFlowOpen.asObservable();
  conductResearchFlow$ = this.conductResearchFlowOpen.asObservable();
  editContentFlow$ = this.editContentFlowOpen.asObservable();
  formatTranslatorFlow$ = this.formatTranslatorFlowOpen.asObservable();
  generatePodcastFlow$ = this.generatePodcastFlowOpen.asObservable();
  refineContentFlow$ = this.refineContentFlowOpen.asObservable();
  brandFormatFlow$ = this.brandFormatFlowOpen.asObservable();
  professionalPolishFlow$ = this.professionalPolishFlowOpen.asObservable();

  constructor() {
    console.log('[MiFlowService] Initialized - Market Intelligence service started');
  }

  openDraftContentFlow(): void {
    console.log('[MiFlowService] Opening draft content flow');
    this.draftContentFlowOpen.next(true);
  }

  closeDraftContentFlow(): void {
    console.log('[MiFlowService] Closing draft content flow');
    this.draftContentFlowOpen.next(false);
  }

  openConductResearchFlow(): void {
    console.log('[MiFlowService] Opening conduct research flow');
    this.conductResearchFlowOpen.next(true);
  }

  closeConductResearchFlow(): void {
    console.log('[MiFlowService] Closing conduct research flow');
    this.conductResearchFlowOpen.next(false);
  }

  openEditContentFlow(): void {
    console.log('[MiFlowService] Opening edit content flow');
    this.editContentFlowOpen.next(true);
  }

  closeEditContentFlow(): void {
    console.log('[MiFlowService] Closing edit content flow');
    this.editContentFlowOpen.next(false);
  }

  openFormatTranslatorFlow(): void {
    console.log('[MiFlowService] Opening format translator flow');
    this.formatTranslatorFlowOpen.next(true);
  }

  closeFormatTranslatorFlow(): void {
    console.log('[MiFlowService] Closing format translator flow');
    this.formatTranslatorFlowOpen.next(false);
  }

  openGeneratePodcastFlow(): void {
    console.log('[MiFlowService] Opening generate podcast flow');
    this.generatePodcastFlowOpen.next(true);
  }

  closeGeneratePodcastFlow(): void {
    console.log('[MiFlowService] Closing generate podcast flow');
    this.generatePodcastFlowOpen.next(false);
  }

  openRefineContentFlow(): void {
    console.log('[MiFlowService] Opening refine content flow');
    this.refineContentFlowOpen.next(true);
  }

  closeRefineContentFlow(): void {
    console.log('[MiFlowService] Closing refine content flow');
    this.refineContentFlowOpen.next(false);
  }

  openBrandFormatFlow(): void {
    console.log('[MiFlowService] Opening brand format flow');
    this.brandFormatFlowOpen.next(true);
  }

  closeBrandFormatFlow(): void {
    console.log('[MiFlowService] Closing brand format flow');
    this.brandFormatFlowOpen.next(false);
  }

  openProfessionalPolishFlow(): void {
    console.log('[MiFlowService] Opening professional polish flow');
    this.professionalPolishFlowOpen.next(true);
  }

  closeProfessionalPolishFlow(): void {
    console.log('[MiFlowService] Closing professional polish flow');
    this.professionalPolishFlowOpen.next(false);
  }

  closeAllFlows(): void {
    console.log('[MiFlowService] Closing all flows');
    this.draftContentFlowOpen.next(false);
    this.conductResearchFlowOpen.next(false);
    this.editContentFlowOpen.next(false);
    this.formatTranslatorFlowOpen.next(false);
    this.generatePodcastFlowOpen.next(false);
    this.refineContentFlowOpen.next(false);
    this.brandFormatFlowOpen.next(false);
    this.professionalPolishFlowOpen.next(false);
  }

  openFlow(flowType: 'draft-content' | 'conduct-research' | 'edit-content' | 'refine-content' | 'format-translator' | 'generate-podcast' | 'brand-format' | 'professional-polish'): void {
    console.log('[MiFlowService] Opening flow:', flowType);
    
    // Close all flows first
    this.closeAllFlows();
    
    // Open the requested flow
    switch (flowType) {
      case 'draft-content':
        this.openDraftContentFlow();
        break;
      case 'conduct-research':
        this.openConductResearchFlow();
        break;
      case 'edit-content':
        this.openEditContentFlow();
        break;
      case 'refine-content':
        this.openRefineContentFlow();
        break;
      case 'format-translator':
        this.openFormatTranslatorFlow();
        break;
      case 'generate-podcast':
        this.openGeneratePodcastFlow();
        break;
      case 'brand-format':
        this.openBrandFormatFlow();
        break;
      case 'professional-polish':
        this.openProfessionalPolishFlow();
        break;
      default:
        console.warn('[MiFlowService] Unknown flow type:', flowType);
    }
  }

  processDraftContent(message: any, context: any): void {
    console.log('[MiFlowService] Processing draft content:', message, context);
  }

  processConductResearch(message: any, context: any): void {
    console.log('[MiFlowService] Processing conduct research:', message, context);
  }

  processEditContent(message: any, context: any): void {
    console.log('[MiFlowService] Processing edit content:', message, context);
  }

  processFormatTranslate(message: any, context: any): void {
    console.log('[MiFlowService] Processing format translate:', message, context);
  }

  processGeneratePodcast(message: any, context: any): void {
    console.log('[MiFlowService] Processing generate podcast:', message, context);
  }

  processRefineContent(message: any, context: any): void {
    console.log('[MiFlowService] Processing refine content:', message, context);
  }

  processBrandFormat(message: any, context: any): void {
    console.log('[MiFlowService] Processing brand format:', message, context);
  }

  processProfessionalPolish(message: any, context: any): void {
    console.log('[MiFlowService] Processing professional polish:', message, context);
  }
}
