import { Component } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from '../../../shared/components/file-upload/file-upload.component';
import { MiFlowService } from '../mi-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { MiChatBridgeService, MarketIntelligenceMetadata } from '../mi-chat-bridge.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'app-mi-conduct-research-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './conduct-research-flow.component.html',
    styleUrls: ['./conduct-research-flow.component.scss']
})
export class MiConductResearchFlowComponent {
  researchTopic = '';
  uploadedContentLink = false;
  pwcProprietaryResearch = true;
  pwcLicensedThirdParty = true;
  externalResearch = false;
  multiple = true;


  // supportingDocFile: File | null = null;
  supportingDocFiles: File[] = [];
  supportingDocInstructions = '';

  researchLinks = '';

  selectSpecificPwcSources = true;

  allPwcProprietarySources = true;
  pwcProprietarySources = [
    { name: 'PwC Industry Edge', selected: true },
    { name: 'PwC Insights', selected: true },
    { name: 's+b Journal', selected: true },
    { name: 'Executive Leadership Hub', selected: true },
    { name: 'The Exchange', selected: true },
    { name: 'PwC Connected Source', selected: true },
    { name: 'PwC Benchmarking', selected: true },
    { name: 'Insights Factory', selected: true },
    { name: 'PwC Intelligence', selected: true },
    { name: 'C-Suite Connections Program', selected: true },
    { name: 'Viewpoint', selected: true },
    { name: 'Analyst and Advisor Relations', selected: true },
    { name: 'Assurance Benchmarking Tools', selected: true },
    { name: 'Policy on Demand', selected: true },
    { name: 'Tax Source', selected: true },
    { name: 'FFG Benchmarking', selected: true },
    { name: 'Inside Industries', selected: true },
    { name: 'Value Store', selected: true }
  ];

  pwcThirdPartySources = [
    { name: 'Factiva', selected: true },
    { name: 'S&P Global- Capital IQ Xpressfeed', selected: true },
    { name: 'S&P Global- Connect', selected: true },
    { name: 'BoardEx', selected: true },
    { name: 'Audit Analytics', selected: true },
    { name: 'S&P Global- SNL Insurance', selected: true },
    { name: 'Claritas', selected: true },
    { name: 'Equifax', selected: true },
    { name: 'Equifax IXI', selected: true },
    { name: 'Definitive Healthcare Provider Database', selected: true },
    { name: 'Sg2 Health Care Intelligence', selected: true },
    { name: 'Strata Market Insights', selected: true },
    { name: 'CompanyIQ', selected: true },
    { name: 'Global Data(Retail)', selected: true },
    { name: 'Technology Business Review', selected: true },
    { name: 'IBIS World', selected: true },
    { name: 'IDC', selected: true },
    { name: 'CFRA Industry Surveys', selected: true }
  ];

  allPwcThirdPartySources = true;

  additionalGuidelines = '';

  researchContent = '';
  isGenerating = false;

  isOpen = false;
  private destroy$ = new Subject<void>();

  constructor(
    public miFlowService: MiFlowService,
    private chatService: ChatService,
    private miChatBridge: MiChatBridgeService
  ) {}

  ngOnInit(): void {
    this.miFlowService.conductResearchFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isOpen => {
        this.isOpen = isOpen;
      });
  }
  removeSupportingDoc(index: number): void {
  this.supportingDocFiles.splice(index, 1);
}

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  get showPwcSourceSelection(): boolean {
    return this.selectSpecificPwcSources && (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }

  get showPwcProprietarySources(): boolean {
    return this.selectSpecificPwcSources && this.pwcProprietaryResearch;
  }

  get showPwcThirdPartySources(): boolean {
    return this.selectSpecificPwcSources && this.pwcLicensedThirdParty;
  }
  get invalidLinks(): boolean {
    if (!this.researchLinks) return false;

    return this.researchLinks
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .some(link => !/^https?:\/\/.+/.test(link));
  }

  // get canGenerateResearch(): boolean {
  //   if (!this.researchTopic.trim()) return false;

  //   if (!this.uploadedContentLink && !this.pwcProprietaryResearch && !this.pwcLicensedThirdParty && !this.externalResearch) {
  //     return false;
  //   }
  //   const hasDoc = !!this.supportingDocFile;
  //   const hasUrl = !!this.researchLinks?.trim();
  //   if (!hasDoc && !hasUrl) return false;

  //   return true;
  // }
  get canGenerateResearch(): boolean {
    if (!this.researchTopic.trim()) return false;

    // const hasSourceSelected = this.uploadedContentLink || this.pwcProprietaryResearch || 
    //                           this.pwcLicensedThirdParty || this.externalResearch;
    
    // if (!hasSourceSelected) return false;


    // Only require doc/link if "Uploaded Content or Link" is selected
    if (this.uploadedContentLink) {
      // const hasDoc = !!this.supportingDocFiles;
      const hasUrl = !!this.invalidLinks;
      if (hasUrl) return false;
    }

    return true;
  }

onSupportingDocsSelected(files: File | File[]): void {
  const incomingFiles = Array.isArray(files) ? files : [files];

  incomingFiles.forEach(file => {
    const alreadyAdded = this.supportingDocFiles.some(
      existing =>
        existing.name === file.name &&
        existing.size === file.size
    );

    if (!alreadyAdded) {
      this.supportingDocFiles.push(file);
    }
  });
}


onSupportingDocSelected(files: File[]): void {
  this.onSupportingDocsSelected(files);
}


  onAllPwcProprietaryToggle(value: boolean): void {
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }

  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }

  onAllPwcThirdPartyToggle(value: boolean): void {
    this.allPwcThirdPartySources = value;
    this.pwcThirdPartySources.forEach(source => source.selected = value);
  }

  onPwcThirdPartySourceChange(): void {
    this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
  }

  onClose(): void {
    this.resetForm();
    this.miFlowService.closeConductResearchFlow();
  }

  back(): void {
    this.miFlowService.closeConductResearchFlow();
    // For MI, opening guided dialog isn't applicable; use scroll/UX handled elsewhere
  }

  resetForm(): void {
    this.researchTopic = '';
    this.uploadedContentLink = false;
    this.pwcProprietaryResearch = true;
    this.pwcLicensedThirdParty = true;
    this.externalResearch = false;
    this.selectSpecificPwcSources = true;
    this.allPwcProprietarySources = true;
    this.pwcProprietarySources.forEach(source => source.selected = true);
    this.allPwcThirdPartySources = true;
    this.pwcThirdPartySources.forEach(source => source.selected = true);
    // this.supportingDocFiles = null;
    this.supportingDocFiles = [];
    this.researchLinks = '';
    this.additionalGuidelines = '';
    this.researchContent = '';
    this.isGenerating = false;
  }

  generateResearch(): void {
    if (!this.canGenerateResearch) {
      console.error('Form validation failed');
      return;
    }

    this.isGenerating = true;
    this.researchContent = '';

    let prompt = `Conduct comprehensive research on the following topic:\n\n`;
    prompt += `Research Topic: ${this.researchTopic}\n`;

    const selectedSources: string[] = [];
    if (this.uploadedContentLink) selectedSources.push('Uploaded Content or Link');
    if (this.pwcProprietaryResearch) selectedSources.push('PwC Proprietary Research');
    if (this.pwcLicensedThirdParty) selectedSources.push('PwC Licensed Third Party Tools');
    if (this.externalResearch) selectedSources.push('External Research');

    if (selectedSources.length > 0) {
      prompt += `Research Sources: ${selectedSources.join(', ')}\n`;
    }

    if (this.supportingDocFiles.length > 0) {
      const fileNames = this.supportingDocFiles.map(f => f.name).join(', ');
      prompt += `Supporting Documents: ${fileNames}\n`;
    }


    if (this.researchLinks.trim()) {
      prompt += `Research Links: ${this.researchLinks}\n`;
    }

    if (this.selectSpecificPwcSources) {
      if (this.pwcProprietaryResearch) {
        const pwcSources: string[] = [];
        this.pwcProprietarySources.forEach((s, idx) => { if (s.selected) pwcSources.push(s.name); });
        if (pwcSources.length > 0) {
          prompt += `PwC Proprietary Research Sources: ${pwcSources.join(', ')}\n`;
        }
      }

      if (this.pwcLicensedThirdParty) {
        const thirdPartySources: string[] = [];
        this.pwcThirdPartySources.forEach((s, idx) => { if (s.selected) thirdPartySources.push(s.name); });
        if (thirdPartySources.length > 0) {
          prompt += `PwC Third Party Tool Sources: ${thirdPartySources.join(', ')}\n`;
        }
      }
    }

    if (this.additionalGuidelines.trim()) {
      prompt += `\nAdditional Guidelines: ${this.additionalGuidelines}\n`;
    }

    // Check if Factiva is selected in third-party sources
    const useFactivaResearch = this.pwcThirdPartySources
      .filter(s => s.name.toLowerCase().includes('factiva'))
      .some(s => s.selected);

    // Append Factiva flag to prompt
    if (useFactivaResearch) {
      prompt += '\n\nUse Factiva Research: true';
    } else {
      prompt += '\n\nUse Factiva Research: false';
    }

    const messages = [{ role: 'user' as const, content: prompt }];

    const sourceGroups: string[] = [];
    if (this.uploadedContentLink) sourceGroups.push('Uploaded Content/Link');
    if (this.pwcProprietaryResearch) sourceGroups.push('PwC Proprietary');
    if (this.pwcLicensedThirdParty) sourceGroups.push('PwC Licensed');
    if (this.externalResearch) sourceGroups.push('External Research');

    console.log('[MiConductResearchFlow] Sending request:', { topic: this.researchTopic, sources: selectedSources });

    const formData = new FormData();
    formData.append("messages", JSON.stringify(messages));
    formData.append("source_groups", JSON.stringify(sourceGroups));
    formData.append("stream", "true");
    formData.append('additional_guidelines', this.additionalGuidelines || '');

    if (this.supportingDocFiles) {
      this.supportingDocFiles.forEach(file => {
      formData.append('files', file);
    });

    }
 
    this.chatService.streamConductResearch(formData).subscribe({
      next: (data: any) => {
        if (typeof data === 'string') {
          this.researchContent += data;
        } else if (data.type === 'content' && data.content) {
          this.researchContent += data.content;
        }
      },
      error: (error: any) => {
        console.error('Error conducting research:', error);
        const errorMessage = 'Sorry, there was an error conducting your research. Please try again.';
        const metadata: MarketIntelligenceMetadata = {
          contentType: 'conduct-research',
          topic: this.researchTopic,
          fullContent: errorMessage,
          showActions: true
        };
        this.miChatBridge.sendToChat(errorMessage, metadata);
        this.isGenerating = false;
        this.resetForm();
      },
      complete: () => {
        console.log('[MiConductResearchFlow] Research generation complete');
        this.isGenerating = false;

        if (this.researchContent && this.researchContent.trim()) {
          const metadata: MarketIntelligenceMetadata = {
            contentType: 'conduct-research',
            topic: this.researchTopic,
            fullContent: this.researchContent,
            showActions: true
          };
          console.log('[MiConductResearchFlow] Sending to chat with metadata:', metadata);
          this.miChatBridge.sendToChat(this.researchContent, metadata);
          this.resetForm();
          this.miFlowService.closeConductResearchFlow();
        }
      }
    });
  }
}
