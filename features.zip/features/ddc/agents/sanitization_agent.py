from typing import TypedDict, Annotated, Sequence, Optional, Dict, Any, Literal
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langchain_openai import AzureChatOpenAI
import operator
import json
import logging
from app.features.ddc.agents.tools import (
    sanitize_presentation,
    validate_sanitization_params,
    list_available_services
)
from app.core.config import config  # 👈 Import config

logger = logging.getLogger(__name__)

class AgentState(TypedDict):
    """State for the sanitization agent"""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    conversation_id: Optional[str]
    collected_data: Dict[str, Any]
    file_data: Optional[bytes]
    file_name: Optional[str]
    custom_template_data: Optional[bytes]
    custom_template_name: Optional[str]

class SanitizationAgent:
    """LangGraph agent for handling sanitization workflow conversationally with tool calling"""
    
    def __init__(self, llm_service, sanitization_service):
        self.llm_service = llm_service
        self.sanitization_service = sanitization_service
        
        # Store tools - use original tools for binding to LLM
        self.tools = [
            sanitize_presentation,
            validate_sanitization_params,
            list_available_services
        ]
        
        # Use Azure OpenAI with config 👇
        self.llm = AzureChatOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT,
            temperature=0
        ).bind_tools(self.tools)
        
        # Build graph
        self.graph = self._build_graph()
        
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow with tool calling"""
        workflow = StateGraph(AgentState)
        
        # Create tool node - we'll handle tool execution in a custom way
        workflow.add_node("agent", self._call_model)
        workflow.add_node("tools", self._execute_tools)
        
        # Define edges
        workflow.set_entry_point("agent")
        
        workflow.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "continue": "tools",
                "end": END
            }
        )
        
        workflow.add_edge("tools", "agent")
        
        return workflow.compile()
    

    def _execute_tools(self, state: AgentState) -> AgentState:
        """Execute tool calls with access to services"""
        last_message = state["messages"][-1]

        logger.info(f'came inside _execute_tools')
        
        tool_messages = []
        
        for tool_call in last_message.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"].copy()  # ← Make a copy
            
            logger.info(f"[Agent] Executing tool: {tool_name}")
            
            try:
                # Execute the appropriate tool
                if tool_name == "sanitize_presentation":
                    # Inject services ONLY during execution, NOT in args
                    tool_args["file_data"] = state.get("file_data")  # ← Add this!
                    tool_args["file_name"] = state.get("file_name")
                    tool_args["sanitization_service"] = self.sanitization_service
                    tool_args["llm_service"] = self.llm_service
                    result = sanitize_presentation.invoke(tool_args)
                elif tool_name == "validate_sanitization_params":
                    result = validate_sanitization_params.invoke(tool_args)
                elif tool_name == "list_available_services":
                    result = list_available_services.invoke(tool_args)
                else:
                    result = {"error": f"Unknown tool: {tool_name}"}
                
                # Create tool message
                tool_message = ToolMessage(
                    content=json.dumps(result),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)
                
            except Exception as e:
                logger.error(f"[Agent] Tool execution error: {e}")
                tool_message = ToolMessage(
                    content=json.dumps({"error": str(e)}),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)
        
        return {"messages": tool_messages}
    
    def _call_model(self, state: AgentState) -> AgentState:
        """Call the LLM with system prompt and tools"""
        
        file_provided = state.get('file_data') is not None
        file_name = state.get('file_name', 'No file')
        logger.info(f'file_provided: {file_provided}, file_name: {file_name}')
        
        system_prompt = f"""You are a DDC (Document De-identification & Compliance) assistant.

    YOUR WORKFLOW (3 STEPS MAXIMUM):

    STEP 1 - GREETING:
    If user says "hi", "hello", or similar:
    → Respond: "Hi! I can help you with: **Sanitization** - Remove sensitive information from PowerPoint presentations. What would you like to do?"

    STEP 2 - COLLECT FILE & SERVICES:
    If user says "sanitize my ppt" or similar:
    → Check if file is uploaded:
    - File status: {'✓ ' + file_name if file_provided else '✗ Not uploaded'}
    
    → If NO file: "Please upload your .pptx file."
    → If file uploaded: "Great! I have {file_name}. Which services do you want?
    
    Available services:
    - replace_client - Replace client names/logos
    - delete_notes - Remove speaker notes  
    - cut_hyperlinks - Remove hyperlinks
    - mask_leadership - Mask leadership names
    - change_competitors - Replace competitor names
    - remove_data - Remove sensitive data
    - conceal_regions - Conceal geographic regions
    - disguise_bus - Disguise business units

    Reply with specific services or say 'all' to use all services."

    STEP 3 - EXECUTE:
    Once you have:
    - File: ✓
    - Services: (either specified OR user wants all)

    → Call sanitize_presentation tool with:
    - file_data, file_name (from state)
    - services: (user's list OR all 8 if they said "all"/"everything"/"default")
    - template: "core" (default)
    - client_identifiers: "" (empty unless specified)
    - additional_guidelines: "" (empty unless specified)

    DEFAULT BEHAVIOR:
    - If user doesn't specify services → Use ALL 8 services
    - Template is always "core" unless user specifies custom
    - Be direct and concise, NOT overly conversational

    CURRENT STATE:
    - File: {'✓ ' + file_name if file_provided else '✗ Not provided'}
    """
        
        messages = [HumanMessage(content=system_prompt)] + state["messages"]
        
        response = self.llm.invoke(messages)
        logger.info(f'inside _call_model {response}')
        return {"messages": [response]}
    
    def _should_continue(self, state: AgentState) -> Literal["continue", "end"]:
        """Decide whether to continue with tool calls or end"""
        last_message = state["messages"][-1]
        
        # If there are tool calls, continue
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "continue"
        
        return "end"
    def process_message_sync(
        self, 
        message: str, 
        conversation_id: Optional[str] = None,
        file_data: Optional[bytes] = None,
        file_name: Optional[str] = None,
        custom_template_data: Optional[bytes] = None,
        custom_template_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process user message through the graph (non-streaming version)
        Returns dict with message, and optionally file_bytes + metadata
        """
        
        initial_state = {
            "messages": [HumanMessage(content=message)],
            "conversation_id": conversation_id,
            "collected_data": {},
            "file_data": file_data,
            "file_name": file_name,
            "custom_template_data": custom_template_data,
            "custom_template_name": custom_template_name
        }
        
        try:
            final_state = self.graph.invoke(initial_state)
            
            # Extract AI response
            ai_messages = [msg for msg in final_state["messages"] if isinstance(msg, AIMessage)]
            response_message = ai_messages[-1].content if ai_messages else "Processing..."
            
            # Check if sanitization was performed
            tool_messages = [msg for msg in final_state["messages"] if isinstance(msg, ToolMessage)]
            sanitization_result = None
            
            for tool_msg in tool_messages:
                try:
                    result_data = json.loads(tool_msg.content)
                    if result_data.get("status") == "success":
                        sanitization_result = result_data
                        break
                except:
                    pass
            
            # ✅ Build result
            result = {
                "message": response_message,
                "conversation_id": conversation_id
            }
            
            # ✅ If sanitization completed, include file data
            if sanitization_result:
                file_bytes = bytes.fromhex(sanitization_result["file_data_base64"])
                
                result.update({
                    "file_bytes": file_bytes,
                    "file_name": sanitization_result["file_name"],
                    "file_size": sanitization_result["file_size"],
                    "summary": sanitization_result["summary"],
                    "plan": sanitization_result["plan"]
                })
            
            return result
                
        except Exception as e:
            logger.error(f"[Agent] Error: {e}", exc_info=True)
            return {
                "message": f"Error: {str(e)}",
                "conversation_id": conversation_id
            }