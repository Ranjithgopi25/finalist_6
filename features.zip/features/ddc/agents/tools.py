from langchain_core.tools import tool
from typing import Dict, Any, Optional
import json
import logging

logger = logging.getLogger(__name__)

# @tool
# def sanitize_presentation(
#     file_data: bytes,
#     file_name: str,
#     services: list,
#     template: str = "core",
#     client_identifiers: str = "",
#     additional_guidelines: str = "",
#     custom_template_data: Optional[bytes] = None,
#     custom_template_name: Optional[str] = None,
#     sanitization_service = None,
#     llm_service = None
# ) -> Dict[str, Any]:
#     """
#     Tool to sanitize a PowerPoint presentation by calling the sanitization service directly.
    
#     Args:
#         file_data: Binary data of the .pptx file
#         file_name: Name of the file
#         services: List of sanitization services to apply
#         template: Template choice ('core', 'existing', or 'custom')
#         client_identifiers: Client identifiers to remove
#         additional_guidelines: Additional sanitization guidelines
#         custom_template_data: Binary data of custom template (if template='custom')
#         custom_template_name: Name of custom template file
#         sanitization_service: SanitizationService instance
#         llm_service: LLM service instance
    
#     Returns:
#         Dictionary with sanitization result including status, file_size, and plan
#     """
#     try:
#         logger.info(f"[Tool] Sanitizing presentation: {file_name}")
        
#         if not sanitization_service:
#             return {
#                 "status": "error",
#                 "message": "Sanitization service not available"
#             }
        
#         # Call sanitization service directly
#         sanitized_bytes, plan = sanitization_service.sanitize_presentation(
#             ppt_bytes=file_data,
#             filename=file_name,
#             selected_services=services,
#             client_identifiers=client_identifiers,
#             template=template,
#             template_bytes=custom_template_data,
#             llm_service=llm_service,
#             additional_guidelines=additional_guidelines
#         )
        
#         result = {
#             "status": "success",
#             "file_size": len(sanitized_bytes),
#             "file_data": sanitized_bytes,
#             "summary": plan.get('summary', {}),
#             "plan": plan.get('items', [])
#         }
        
#         logger.info("[Tool] Sanitization completed successfully")
#         return result
            
#     except Exception as e:
#         logger.error(f"[Tool] Sanitization error: {e}")
#         return {
#             "status": "error",
#             "message": str(e)
#         }



@tool
def sanitize_presentation(
    file_data: bytes,
    file_name: str,
    services: list,
    template: str = "core",
    client_identifiers: str = "",
    additional_guidelines: str = "",
    custom_template_data: Optional[bytes] = None,
    custom_template_name: Optional[str] = None,
    sanitization_service = None,
    llm_service = None
) -> Dict[str, Any]:
    """Tool to sanitize a PowerPoint presentation"""
    try:
        logger.info(f"[Tool] Sanitizing presentation: {file_name}")
        
        if not sanitization_service:
            return {
                "status": "error",
                "message": "Sanitization service not available"
            }
        
        # Call sanitization service
        sanitized_bytes, plan = sanitization_service.sanitize_presentation(
            ppt_bytes=file_data,
            filename=file_name,
            selected_services=services,
            client_identifiers=client_identifiers,
            template=template,
            template_bytes=custom_template_data,
            llm_service=llm_service,
            additional_guidelines=additional_guidelines
        )
        
        result = {
            "status": "success",
            "file_size": len(sanitized_bytes),
            "file_name": file_name.replace('.pptx', '_sanitized.pptx'),
            # ✅ RETURN FILE AS BASE64 SO IT CAN BE JSON SERIALIZED
            "file_data_base64": sanitized_bytes.hex(),  # or use base64.b64encode(sanitized_bytes).decode()
            "summary": plan.get('summary', {}),
            "plan": plan.get('items', [])
        }
        
        logger.info("[Tool] Sanitization completed successfully")
        return result
            
    except Exception as e:
        logger.error(f"[Tool] Sanitization error: {e}")
        return {
            "status": "error",
            "message": str(e)
        }

@tool
def validate_sanitization_params(
    services: Optional[list] = None,
    template: Optional[str] = None,
    file_provided: bool = False
) -> Dict[str, Any]:
    """
    Tool to validate if all required parameters for sanitization are provided.
    
    Args:
        services: List of sanitization services
        template: Template choice
        file_provided: Whether a file has been provided
    
    Returns:
        Dictionary with validation result and missing parameters
    """
    missing = []
    
    if not file_provided:
        missing.append("presentation_file")
    
    if not services or len(services) == 0:
        missing.append("services")
    
    if not template:
        missing.append("template")
    
    valid_services = [
        "replace_client", "delete_notes", "cut_hyperlinks", 
        "mask_leadership", "change_competitors", "remove_data",
        "conceal_regions", "disguise_business"
    ]
    
    invalid_services = []
    if services:
        invalid_services = [s for s in services if s not in valid_services]
    
    return {
        "is_valid": len(missing) == 0 and len(invalid_services) == 0,
        "missing_params": missing,
        "invalid_services": invalid_services,
        "valid_services": valid_services
    }

@tool
def list_available_services() -> Dict[str, Any]:
    """
    Tool to list all available sanitization services and their descriptions.
    
    Returns:
        Dictionary with service names and descriptions
    """
    services = {
        "replace_client": "Replace client names with generic placeholders",
        "delete_notes": "Remove speaker notes from all slides",
        "cut_hyperlinks": "Remove all hyperlinks from the presentation",
        "mask_leadership": "Mask leadership names and titles",
        "change_competitors": "Replace competitor names with generic terms",
        "remove_data": "Remove sensitive data and numbers",
        "conceal_regions": "Conceal geographic regions and locations",
        "disguise_business": "Disguise business-specific terminology"
    }
    
    templates = {
        "core": "Use PwC core template",
        "existing": "Keep existing template from the presentation",
        "custom": "Use a custom template (requires custom_template file)"
    }
    
    return {
        "services": services,
        "templates": templates
    }