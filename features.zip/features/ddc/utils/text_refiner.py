import os
import io
import docx
import PyPDF2
from pptx import Presentation
from openai import AzureOpenAI
import pandas as pd
import logging
from io import BytesIO
from app.core.config import config

logger = logging.getLogger(__name__)

# Azure OpenAI client setup

client = AzureOpenAI(
    azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
    api_key=config.AZURE_OPENAI_API_KEY,
    api_version=config.AZURE_OPENAI_API_VERSION
)


# ------------------------------
# 1. TEXT EXTRACTION HELPERS
# ------------------------------

def extract_text_from_pdf(file_bytes: bytes) -> str:
    pdf_reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
    text = []
    for page in pdf_reader.pages:
        text.append(page.extract_text() or "")
    return "\n".join(text).strip()


def extract_text_from_docx(file_bytes: bytes) -> str:
    doc = docx.Document(io.BytesIO(file_bytes))
    return "\n".join([para.text for para in doc.paragraphs]).strip()


def extract_text_from_txt(file_bytes: bytes) -> str:
    return file_bytes.decode("utf-8", errors="ignore").strip()


def extract_text_from_pptx(file_bytes: bytes) -> str:
    prs = Presentation(io.BytesIO(file_bytes))
    slides_text = []
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                slides_text.append(shape.text)
    return "\n".join(slides_text).strip()

def extract_text_from_xlsx(path):
    sheets = pd.read_excel(path, sheet_name=None)

    data_str = "".join(f"=== {name} ==={df.to_csv(index=False)}" for name, df in sheets.items())
    
    return data_str

def excel_bytes_to_string(xlsx_bytes: bytes) -> str:
    sheets = pd.read_excel(BytesIO(xlsx_bytes), sheet_name=None, engine="openpyxl")
    return "".join(f"=== {name} ===\n{df.to_csv(index=False)}" for name, df in sheets.items())

def extract_text_from_any(filename: str, file_bytes: bytes) -> str:
    ext = filename.lower()

    if ext.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes)
    if ext.endswith(".docx"):
        return extract_text_from_docx(file_bytes)
    if ext.endswith(".txt"):
        return extract_text_from_txt(file_bytes)
    if ext.endswith(".pptx"):
        return extract_text_from_pptx(file_bytes)
    if ext.endswith(".xlsx"):
        return excel_bytes_to_string(file_bytes)    
        
    

    raise ValueError(f"Unsupported file type: {filename}")
    


# ------------------------------
# 2. LLM TEXT REFINER
# ------------------------------
#If there is chart data then extract that too and mention it clearly along with the data in the refined content.

def refine_text_for_slides(raw_text: str) -> str:
    """
    Sends extracted text to Azure OpenAI and returns
    a clean summary suitable as a PlusDocs prompt.
    """
    logger.info(f"raw text inside refine_text_for_slides {raw_text}")

    prompt = f"""
You are a slide content refiner.

The user has provided raw text from a document. Your job:

1. Identify the important topics, key points, and structure. 
2. Remove noise, redundant lines, formatting issues, repeated content, empty lines.
3. Don't miss out on any vital information including links and research content.

Raw text:
------------------
{raw_text}
------------------

Return the refined slide-ready content.
"""

    response = client.chat.completions.create(
        model= 'azure.gpt-5.1',
        messages=[
            {"role": "system", "content": "You refine messy text into structured slide content."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=30000
    )
    logger.info(f"llm response {response.choices[0].message.content.strip()}")
    return response.choices[0].message.content.strip()


def refine_text_for_placemat(raw_text: str, pageNum: str) -> str:
    """
    Sends extracted text to Azure OpenAI and returns
    a clean summary suitable as a PlusDocs prompt.
    """
    logger.info(f"raw text inside refine_text_for_placemat {raw_text} ,page: {pageNum}")

    prompt = f"""
You are a placemat content refiner. You have to refine the content for {pageNum} page(s) of placemat.

The user has provided raw text from a document. Your job:

1. Identify the important topics, key points, and structure. 
2. Remove noise, redundant lines, formatting issues, repeated content, empty lines.
3. Don't miss out on any vital information including links and research content.

Raw text:
------------------
{raw_text}
------------------

Return the refined placemat-ready content.
"""

    response = client.chat.completions.create(
        model= 'azure.gpt-5.1',
        messages=[
            {"role": "system", "content": "You refine messy text into structured slide content."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=30000
    )
    logger.info(f"llm response for placemat: {response.choices[0].message.content.strip()}")
    return response.choices[0].message.content.strip()


def extract_page_count(customization: str) -> int:
    # Default fallback
    layout = None
    pages = None

    # Split by commas
    parts = [p.strip() for p in customization.split(",")]

    for part in parts:
        if part.lower().startswith("layout:"):
            layout = part.split(":", 1)[1].strip().lower()

        elif part.lower().startswith("pages:"):
            value = part.split(":", 1)[1].strip()
            #pages = value
            if value.isdigit():
               pages = int(value)

    # If "Pages" is explicitly given, always use it
    if pages:
        return pages

    # Otherwise infer from layout
    if layout == "two-page":
        return 2
    else:
        # default for one-page or unknown
        return 1


def extract_meaning_from_image(img_bytes: str, ext: str) -> str:
   

    prompt = """
    You area master of extracting data and details from images. Analyze this image and extract:
    - Key data points
    - All and actual Text content
    - Any charts, tables, or trends
    - Meaning/summary of what the image represents
    - Everything that is possible to extract from the image
    """
    print('came inside extract_meaning_from_image')
    response = client.chat.completions.create(
        model="azure.gpt-5.1",
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/{ext};base64,{img_bytes}"
                        }
                    }
                ]
            }
        ],
        max_tokens=30000
    )
    
    return response.choices[0].message.content
