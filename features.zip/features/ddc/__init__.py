from app.features.ddc.router import get_router

__all__ = ["get_router"]
