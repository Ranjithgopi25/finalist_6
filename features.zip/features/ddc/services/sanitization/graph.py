import os
import re
import json
import logging
import base64
import hashlib
import tempfile
from io import BytesIO
from langgraph.graph import StateGraph, END
from collections import defaultdict
from typing import List, Dict, TypedDict, Optional
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage
from pydantic import BaseModel
from .prompt import MASK_CLIENT_PROMPT, MASK_PERSON_PROMPT, MASK_COMPETITOR_PROMPT,MASK_LOCATION_PROMPT,MASK_BU_PROMPT,MASK_CLIENT_DATA_PROMPT


# API variables
api_key = os.getenv("AI_API_KEY")
api_base = os.getenv("AI_ENDPOINT")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
deployment_name = os.getenv("AI_MODEL")

# =========================================================
# LLMs

TEXT_LLM = AzureChatOpenAI(
    azure_deployment=deployment_name,
    api_key=api_key,
    azure_endpoint=api_base,
    api_version=api_version,
    temperature=0,
)

VISION_LLM = AzureChatOpenAI(
    azure_deployment=deployment_name,
    api_key=api_key,
    azure_endpoint=api_base,
    api_version=api_version,
    temperature=0,
)

# ====================================================


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# ---------------------------
# TypedDict for LangGraph state
# ---------------------------
class PPTGraphState(TypedDict, total=False):
    input_path: str
    output_path: str
    prs: Presentation
    blocks: List[Dict]
    options: Dict[str, bool]
    sanitizer: "PPTSanitizer"

# ---------------------------
# Pydantic models for structured LLM output
# ---------------------------
class SanitizedBlock(BaseModel):
    slide_index: int
    shape_id: int
    paragraph_index: int
    text: str

    # ✅ REQUIRED FOR TABLES
    row_index: Optional[int] = None
    col_index: Optional[int] = None
    type: Optional[str] = None
class SanitizedResponse(BaseModel):
    blocks: List[SanitizedBlock]

class LogoDetectionResult(BaseModel):
    is_logo: bool

# ---------------------------
# Main Sanitizer class
# ---------------------------
class PPTSanitizer:
    LOGO_CACHE: Dict[str, bool] = {}
    SUPPORTED_MIME_TYPES = {"image/png", "image/jpeg", "image/jpg", "image/webp"}

    def __init__(self, text_llm, vision_llm, options: dict | None = None,):
        self.text_llm = text_llm
        self.vision_llm = vision_llm
        self.options = options or {}

        self.sanitization_stats = defaultdict(int)

    # ---------------------------
    # TEXT BLOCK HELPERS

    def extract_text_blocks(self, pptx_path: str) -> List[Dict]:
        prs = Presentation(pptx_path)
        blocks: List[Dict] = []

        for slide_idx, slide in enumerate(prs.slides):
            for shape in slide.shapes:

                # --------------------------------------------------
                # 1️⃣ NORMAL TEXT SHAPES
                # --------------------------------------------------
                if shape.has_text_frame:
                    for para_idx, para in enumerate(shape.text_frame.paragraphs):
                        text = para.text.strip()
                        if not text:
                            continue

                        blocks.append({
                            "slide_index": slide_idx,
                            "shape_id": shape.shape_id,
                            "paragraph_index": para_idx,
                            "text": text,
                            "type": "text"
                        })

                # --------------------------------------------------
                # 2️⃣ TABLES
                # --------------------------------------------------
                elif shape.has_table:
                    table = shape.table

                    for row_idx, row in enumerate(table.rows):
                        for col_idx, cell in enumerate(row.cells):
                            tf = cell.text_frame
                            for para_idx, para in enumerate(tf.paragraphs):
                                text = para.text.strip()
                                if not text:
                                    continue

                                blocks.append({
                                    "slide_index": slide_idx,
                                    "shape_id": shape.shape_id,
                                    "row_index": row_idx,
                                    "col_index": col_idx,
                                    "paragraph_index": para_idx,
                                    "text": text,
                                    "type": "table"
                                })
        return blocks

    _XML_INVALID_CHARS = re.compile(
        r"[\x00-\x08\x0B\x0C\x0E-\x1F]"
    )


    def sanitize_for_xml(self, text: str) -> str:
        if not text:
            return ""
        return self._XML_INVALID_CHARS.sub("", text)



    def replace_text_preserve_structure(self, paragraph, new_text: str):
        """
        Replace ONLY <a:t> nodes.
        Works for text frames AND table cells.
        Preserves formatting.
        XML-safe.
        """
        new_text = self.sanitize_for_xml(new_text)

        text_nodes = []

        # --------------------------------------------------
        # 1️⃣ Collect ALL <a:t> nodes via XML (most reliable)
        # --------------------------------------------------
        for el in paragraph._p.iter():
            if el.tag.endswith("}t") or el.tag.endswith("t"):
                if el.text is not None:
                    text_nodes.append(el)

        if not text_nodes:
            return  # Nothing editable

        remaining = new_text

        for node in text_nodes:
            if not remaining:
                node.text = ""
                continue

            original_len = len(node.text)
            node.text = remaining[:original_len]
            remaining = remaining[original_len:]

        # Append overflow to last <a:t>
        if remaining:
            text_nodes[-1].text += remaining


    def apply_sanitized_text(self, prs: Presentation, sanitized: List[Dict]):
        """
        Applies sanitized text to:
        - Normal text shapes
        - Table cells
        Preserves all formatting and structure.
        """
        for block in sanitized:
            slide_idx = block.get("slide_index")
            shape_id = block.get("shape_id")
            new_text = block.get("text", "")

            if slide_idx is None or shape_id is None:
                continue

            slide = prs.slides[slide_idx]

            for shape in slide.shapes:
                if shape.shape_id != shape_id:
                    continue

                if shape.has_table and ("row_index" not in block or "col_index" not in block):
                    continue

                # --------------------------------------------------
                # 1️⃣ NORMAL TEXT SHAPES
                # --------------------------------------------------
                if shape.has_text_frame:
                    para_idx = block.get("paragraph_index", 0)

                    if para_idx >= len(shape.text_frame.paragraphs):
                        continue

                    paragraph = shape.text_frame.paragraphs[para_idx]
                    self.replace_text_preserve_structure(paragraph, new_text)

                # --------------------------------------------------
                # 2️⃣ TABLE CELLS
                # --------------------------------------------------
                elif shape.has_table:
                    row_idx = block.get("row_index")
                    col_idx = block.get("col_index")
                    para_idx = block.get("paragraph_index", 0)

                    if row_idx is None or col_idx is None:
                        continue

                    table = shape.table

                    if row_idx >= len(table.rows):
                        continue
                    if col_idx >= len(table.columns):
                        continue

                    cell = table.cell(row_idx, col_idx)
                    paragraphs = cell.text_frame.paragraphs

                    if para_idx >= len(paragraphs):
                        continue

                    paragraph = paragraphs[para_idx]
                    self.replace_text_preserve_structure(paragraph, new_text)


    # ---------------------------
    # NOTES / COMMENTS
    # ---------------------------
    def delete_notes(self, prs: Presentation) -> int:
        removed = 0
        for slide in prs.slides:
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text:
                slide.notes_slide.notes_text_frame.clear()
                removed += 1
        return removed

    def delete_comments(self, prs: Presentation) -> int:
        removed = 0
        for slide in prs.slides:
            try:
                rels_to_remove = [
                    (rId, rel)
                    for rId, rel in slide.part.rels.items()
                    if "comments" in rel.target_ref
                ]
                if rels_to_remove:
                    removed += 1

                for rId, rel in rels_to_remove:
                    comment_part = rel._target
                    slide.part.drop_rel(rId)
                    try:
                        comment_part.package.drop_part(comment_part)
                    except Exception:
                        logger.warning(f"Could not drop comment part {comment_part.partname}")
            except Exception as e:
                logger.warning(f"Failed to remove comments on slide {slide.slide_id}: {e}")
        return removed
        
    # HYPERLINK REMOVAL
    def cut_hyperlinks(self, prs: Presentation):
        removed_count = 0
        def remove_hyperlinks_from_shape(shape):
            nonlocal removed_count
            if shape.shape_type != MSO_SHAPE_TYPE.GROUP:
                if hasattr(shape, "click_action") and hasattr(shape.click_action, "hyperlink"):
                    if shape.click_action.hyperlink is not None:
                        shape.click_action.hyperlink.address = None
                        removed_count += 1

            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if hasattr(run, "hyperlink") and run.hyperlink is not None:
                            run.hyperlink.address = None
                            removed_count += 1

            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                for sub_shape in shape.shapes:
                    remove_hyperlinks_from_shape(sub_shape)

        for slide in prs.slides:
            for shape in slide.shapes:
                remove_hyperlinks_from_shape(shape)

        self.sanitization_stats["hyperlinks_removed"] = removed_count


    # ---------------------------
    # LOGO DETECTION / REMOVAL
    # ---------------------------
    def is_logo_image(self, image_bytes: bytes, mime_type: str) -> bool:
        if mime_type not in self.SUPPORTED_MIME_TYPES:
            return False
        img_hash = hashlib.sha256(image_bytes).hexdigest()
        if img_hash in self.LOGO_CACHE:
            return self.LOGO_CACHE[img_hash]

        b64 = base64.b64encode(image_bytes).decode("utf-8")
        prompt = """You are an image classifier.
                    Task:
                    Determine if this image is a COMPANY or BRAND LOGO.
                    Rules:
                    - Logos are brand marks or wordmarks
                    - Photos, charts, screenshots are NOT logos
                    - Return ONLY valid JSON

                    Output:
                    {"is_logo": true | false}
                """
        response = self.vision_llm.with_structured_output(schema=LogoDetectionResult).invoke([
            HumanMessage(content=[{"type": "text", "text": prompt},
                                  {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64}"}}])
        ])
        self.LOGO_CACHE[img_hash] = response.is_logo
        return response.is_logo

    def remove_logo_images(self, prs: Presentation):
        for slide in prs.slides:
            for shape in list(slide.shapes):
                if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                    slide.shapes._spTree.remove(shape._element)
                    self.sanitization_stats["logos_removed"] += 1

    # ---------------------------
    # LLM MASKING FUNCTIONS
    # ---------------------------
    def mask_client_name_llm(self, blocks: List[Dict]) -> List[Dict]:
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content= MASK_CLIENT_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])
        if not isinstance(response, SanitizedResponse):
            raise RuntimeError(f"Unexpected structured response: {type(response)}")
        TOKEN = "[CLIENT]"
        count = sum(b.text.count(TOKEN) for b in response.blocks)
        self.sanitization_stats["client_name_replacements"] += count

        return [block.model_dump() for block in response.blocks]    
            

    def mask_person_info_llm(self, blocks: List[Dict]) -> List[Dict]:
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_PERSON_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])
        if not isinstance(response, SanitizedResponse):
            raise RuntimeError(f"Unexpected structured response: {type(response)}")
        self.sanitization_stats["person_names_removed"] += len(response.blocks)
        return [block.model_dump() for block in response.blocks]

    def mask_competitor_product_name_llm(self, blocks: List[Dict]) -> List[Dict]:
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_COMPETITOR_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])

        COMPETITOR_TOKENS = ["[COMPETITOR]", "[PRODUCT]", "[AUDITOR]",]
        count = 0
        for block in response.blocks:
            for token in COMPETITOR_TOKENS:
                count += block.text.count(token)

        self.sanitization_stats["competitor_sanitized"] += count

        return [block.model_dump() for block in response.blocks]

    def mask_client_specific_data_llm(self, blocks: List[Dict]) -> List[Dict]:
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_CLIENT_DATA_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])
        if not isinstance(response, SanitizedResponse):
            raise RuntimeError(f"Unexpected structured response: {type(response)}")
        self.sanitization_stats["identifiers_redacted"] += len(response.blocks)
        return [block.model_dump() for block in response.blocks]

    def mask_client_location_llm(self, blocks: List[Dict]) -> List[Dict]:
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_LOCATION_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])
        if not isinstance(response, SanitizedResponse):
            raise RuntimeError(f"Unexpected structured response: {type(response)}")
        LOCATION_TOKEN = "[LOCATION]"
        count = sum(block.text.count(LOCATION_TOKEN) for block in response.blocks)
        self.sanitization_stats["locations_redacted"] += count

        return [block.model_dump() for block in response.blocks]

    def mask_client_bus_llm(self, blocks: List[Dict]) -> List[Dict]:
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_BU_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])
        if not isinstance(response, SanitizedResponse):
            raise RuntimeError(f"Unexpected structured response: {type(response)}")
        BU_TOKEN = "[BU]"
        count = sum(block.text.count(BU_TOKEN) for block in response.blocks)
        self.sanitization_stats["business_units"] += count
        return [block.model_dump() for block in response.blocks]
    
    def correct_grammar_llm(self, blocks: List[Dict]) -> List[Dict]:
        """
        Correct grammar for all text blocks.
        """
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        # Create a prompt asking the LLM to correct grammar
        GRAMMAR_PROMPT = "Please correct the grammar in the following text. Keep original meaning and structure."
        response = structured_llm.invoke([
            HumanMessage(content=GRAMMAR_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])
        
        if not isinstance(response, SanitizedResponse):
            raise RuntimeError(f"Unexpected structured response: {type(response)}")

        self.sanitization_stats["grammar_corrected"] = len(response.blocks)

        return [block.model_dump() for block in response.blocks]


    # ---------------------------
    # MAIN SANITIZATION WORKFLOW
    # ---------------------------
    def sanitize_presentation(self, input_file, output_path=None) -> BytesIO:
        # Temp input
        if isinstance(input_file, str):
            input_path = input_file
        else:
            tmp_input = tempfile.NamedTemporaryFile(delete=False, suffix=".pptx")
            tmp_input.write(input_file.read())
            tmp_input.close()
            input_path = tmp_input.name

        # Temp output
        if output_path is None:
            tmp_output = tempfile.NamedTemporaryFile(delete=False, suffix=".pptx")
            tmp_output.close()
            output_path = tmp_output.name

        prs = Presentation(input_path)
        blocks = self.extract_text_blocks(input_path)

        # --- Apply LLM masking ---
        if self.options.get("names"):
            blocks = self.mask_client_name_llm(blocks)
        if self.options.get("personal_info"):
            blocks = self.mask_person_info_llm(blocks)
        if self.options.get("competitor"):
            blocks = self.mask_competitor_product_name_llm(blocks)
        if self.options.get("locations"):
            blocks = self.mask_client_location_llm(blocks)
        if self.options.get("business_units"):
            blocks = self.mask_client_bus_llm(blocks)
        if self.options.get("numeric_data"):
            blocks = self.mask_client_specific_data_llm(blocks)

        # --- Other sanitizations ---
        if self.options.get("logos"):
            self.remove_logo_images(prs)
        if self.options.get("metadata"):
            notes_removed = self.delete_notes(prs)
            comments_removed = self.delete_comments(prs)
            self.sanitization_stats["notes_removed"] = notes_removed
            self.sanitization_stats["comments_removed"] = comments_removed

        if self.options.get("hyperlinks"):
            self.cut_hyperlinks(prs)

        # Apply sanitized text
        self.apply_sanitized_text(prs, blocks)

        # Save PPT
        prs.save(output_path)

        # Read into BytesIO
        with open(output_path, "rb") as f:
            sanitized_bytes = BytesIO(f.read())
            sanitized_bytes.seek(0)

        # Cleanup temp files
        if not isinstance(input_file, str):
            os.unlink(input_path)
        if output_path and ("tmp_output" in locals()):
            os.unlink(output_path)

        return sanitized_bytes

    # Get stats
    def get_stats(self):
        return dict(self.sanitization_stats)

# ===========================
# LANGGRAPH NODES
# ===========================

def load_node(state: PPTGraphState):
    state["prs"] = Presentation(state["input_path"])
    state["blocks"] = state["sanitizer"].extract_text_blocks(state["input_path"])

    return state



def mask_client_name_node(state: PPTGraphState):
    if state["options"].get("names"):
        state["blocks"] = state["sanitizer"].mask_client_name_llm(state["blocks"])
    return state


def logos_node(state: PPTGraphState):
    if state["options"].get("logos"):
        state["sanitizer"].remove_logo_images(state["prs"])
    return state


def metadata_node(state: PPTGraphState):
    if state["options"].get("metadata"):
        notes = state["sanitizer"].delete_notes(state["prs"])
        comments = state["sanitizer"].delete_comments(state["prs"])
        state["sanitizer"].sanitization_stats["notes_removed"] = notes
        state["sanitizer"].sanitization_stats["comments_removed"] = comments
    return state


def hyperlinks_node(state: PPTGraphState):
    if state["options"].get("hyperlinks"):
        state["sanitizer"].cut_hyperlinks(state["prs"])
    return state


def mask_person_node(state: PPTGraphState):
    if state["options"].get("personal_info"):
        state["blocks"] = state["sanitizer"].mask_person_info_llm(state["blocks"])
    return state


def mask_competitor_node(state: PPTGraphState):
    if state["options"].get("competitor"):
        state["blocks"] = state["sanitizer"].mask_competitor_product_name_llm(state["blocks"])
    return state


def mask_numeric_node(state: PPTGraphState):
    if state["options"].get("numeric_data"):
        state["blocks"] = state["sanitizer"].mask_client_specific_data_llm(state["blocks"])
    return state


def mask_location_node(state: PPTGraphState):
    if state["options"].get("locations"):
        state["blocks"] = state["sanitizer"].mask_client_location_llm(state["blocks"])
    return state

def mask_bu_node(state: PPTGraphState):
    if state["options"].get("business_units"):
        state["blocks"] = state["sanitizer"].mask_client_bus_llm(state["blocks"])
    return state

def grammar_node(state: PPTGraphState):
    # Always apply grammar correction
    state["blocks"] = state["sanitizer"].correct_grammar_llm(state["blocks"])
    return state

def save_node(state: PPTGraphState):
    state["sanitizer"].apply_sanitized_text(state["prs"], state["blocks"])
    state["prs"].save(state["output_path"])
    return state



# ===========================
# LANGGRAPH DEFINITION
# ===========================

graph = StateGraph(PPTGraphState)

graph.add_node("load", load_node)
graph.add_node("mask_client", mask_client_name_node)
graph.add_node("logos", logos_node)
graph.add_node("metadata", metadata_node)
graph.add_node("hyperlinks", hyperlinks_node)
graph.add_node("mask_person", mask_person_node)
graph.add_node("mask_competitor", mask_competitor_node)
graph.add_node("mask_numeric", mask_numeric_node)
graph.add_node("mask_location", mask_location_node)
graph.add_node("mask_bu", mask_bu_node)
graph.add_node("grammar", grammar_node)
graph.add_node("save", save_node)

graph.set_entry_point("load")

graph.add_edge("load", "mask_client")
graph.add_edge("mask_client", "logos")
graph.add_edge("logos", "metadata")
graph.add_edge("metadata", "hyperlinks")
graph.add_edge("hyperlinks", "mask_person")
graph.add_edge("mask_person", "mask_competitor")
graph.add_edge("mask_competitor", "mask_numeric")
graph.add_edge("mask_numeric","mask_location")
graph.add_edge("mask_location", "mask_bu")
graph.add_edge("mask_bu", "grammar")
graph.add_edge("grammar", "save")
graph.add_edge("save", END)

ppt_graph = graph.compile()

