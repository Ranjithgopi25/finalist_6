# ============================================================
# graph.py
# LangGraph orchestration for Refine Content
# CLEAN + STRUCTURED + EXTENSIBLE (PATCHED)
# ============================================================

from typing import Optional, Dict, Any, List, Literal
from pydantic import BaseModel, Field

from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig


# ============================================================
# STATE
# ============================================================

class RefineGraphState(BaseModel):
    # -------- INPUT --------
    original_content: str
    services: Dict[str, Any]

    # -------- FLAGS --------
    is_expand: bool = False
    is_compress: bool = False
    apply_tone: bool = False
    apply_research: bool = False
    apply_edit: bool = False
    apply_suggestions: bool = False
    trim_applied: bool = False

    tone: Optional[str] = None

    # -------- TARGETS --------
    hard_target_word_count: Optional[int] = None
    grow_target_word_count: Optional[int] = None
    max_allowed_word_count: Optional[int] = None

    # -------- CONTENT --------
    cleaned_content: Optional[str] = None
    grown_content: Optional[str] = None
    final_output: Optional[str] = None
    suggestions: Optional[str] = None

    # -------- METRICS --------
    current_word_count: Optional[int] = None
    retry_count: int = 0
    max_retries: int = 3

    # -------- CONTROL --------
    next_step: Optional[
        Literal[
            "SEMANTIC_CLEAN",
            "RESEARCH_ENRICH",
            "EXPAND_GROW",
            "TONE_ADJUST",
            "EDIT_SEQUENCE",
            "EXPAND_TRIM",
            "COMPRESS_ENFORCE",
            "VALIDATE",
            "SUGGESTIONS_ONLY",
            "COMPLETE",
            "FAIL",
        ]
    ] = "SEMANTIC_CLEAN"

    warnings: List[str] = Field(default_factory=list)

    class Config:
        extra = "forbid"


# ============================================================
# HELPERS
# ============================================================

def _get_latest_text(state: RefineGraphState) -> str:
    return (
        state.final_output
        or state.grown_content
        or state.cleaned_content
        or state.original_content
    )


# ============================================================
# PLANNER
# ============================================================

def planner_node(state: RefineGraphState):
    print("\n[PLANNER] Initializing")

    services = state.services
    target = int(services.get("requested_word_limit", 0))
    is_expand = bool(services.get("is_expand"))

    updates = {
        "is_expand": is_expand,
        "is_compress": not is_expand,
        "apply_tone": bool(services.get("tone")),
        "apply_research": bool(services.get("research")),
        "apply_edit": bool(services.get("edit")),
        "apply_suggestions": bool(services.get("suggestions")),
        "tone": services.get("tone"),
        "hard_target_word_count": target,
    }

    if is_expand:
        updates.update(
            {
                "grow_target_word_count": int(target * 1.03),
                "max_allowed_word_count": int(target * 1.05),
            }
        )

    return {**updates, "next_step": "SEMANTIC_CLEAN"}


# ============================================================
# SEMANTIC CLEAN
# ============================================================

async def semantic_clean_node(state: RefineGraphState, config: RunnableConfig):
    print("\n[SEMANTIC_CLEAN]")

    llm = config["configurable"]["llm_service"]

    messages = [
        {
            "role": "system",
            "content": (
                "You are a PwC senior editor.\n"
                "Clean grammar, normalize structure.\n"
                "NO expansion. NO compression."
            ),
        },
        {"role": "user", "content": state.original_content},
    ]

    cleaned = await llm.chat_completion(messages)
    wc = len(cleaned.split())

    return {
        "cleaned_content": cleaned,
        "current_word_count": wc,
        "next_step": (
            "RESEARCH_ENRICH"
            if state.apply_research
            else "EXPAND_GROW"
            if state.is_expand
            else "TONE_ADJUST"
        ),
    }


# ============================================================
# RESEARCH (PATCHED – GROUNDED)
# ============================================================

async def research_enrich_node(state: RefineGraphState, config: RunnableConfig):
    print("\n[RESEARCH_ENRICH]")

    llm = config["configurable"]["llm_service"]

    research_block = ""
    if state.services.get("pwc_research_doc"):
        research_block = f"""

PWC RESEARCH (MANDATORY SOURCE):
{state.services['pwc_research_doc']}

RULES:
- Use this research FIRST
- Do NOT contradict it
- Do NOT invent facts
"""

    messages = [
        {
            "role": "system",
            "content": (
                "You are a PwC research editor.\n"
                "Strengthen existing arguments using provided research.\n"
                "Do NOT add new sections.\n"
                "Do NOT change structure."
            ),
        },
        {
            "role": "user",
            "content": state.cleaned_content + research_block,
        },
    ]

    enriched = await llm.chat_completion(messages)

    return {
        "cleaned_content": enriched,
        "current_word_count": len(enriched.split()),
        "next_step": "EXPAND_GROW" if state.is_expand else "TONE_ADJUST",
    }


# ============================================================
# EXPAND — GROW (PATCHED WITH HARD GUARD)
# ============================================================

async def expand_grow_node(state: RefineGraphState, config: RunnableConfig):
    print("\n[EXPAND_GROW]")

    llm = config["configurable"]["llm_service"]

    # Build safe bounds for the system prompt (handle None gracefully)
    grow_min = state.grow_target_word_count or "an increased"
    grow_max = state.max_allowed_word_count or "a reasonable maximum"

    messages = [
        {
            "role": "system",
            "content": (
                f"Expand content to between {grow_min} "
                f"and {grow_max} words.\n"
                "Preserve structure."
            ),
        },
        {"role": "user", "content": state.cleaned_content},
    ]

    grown = await llm.chat_completion(messages)
    wc = len(grown.split())

    # 🚨 HARD OVERSHOOT GUARD — only compare when a numeric max is provided
    if isinstance(state.max_allowed_word_count, int) and wc > state.max_allowed_word_count:
        print(f"[EXPAND_GROW] Overshoot {wc} > {state.max_allowed_word_count} → TRIM")
        return {
            "grown_content": grown,
            "current_word_count": wc,
            "next_step": "EXPAND_TRIM",
        }

    return {
        "grown_content": grown,
        "current_word_count": wc,
        "next_step": "TONE_ADJUST",
    }


# ============================================================
# TONE
# ============================================================

async def tone_adjust_node(state: RefineGraphState, config: RunnableConfig):
    if not state.apply_tone:
        return {"next_step": "EDIT_SEQUENCE"}

    print(f"\n[TONE_ADJUST] {state.tone}")

    llm = config["configurable"]["llm_service"]
    source = _get_latest_text(state)

    messages = [
        {
            "role": "system",
            "content": (
                f"Rewrite in '{state.tone}' tone.\n"
                "Preserve meaning and length."
            ),
        },
        {"role": "user", "content": source},
    ]

    toned = await llm.chat_completion(messages)

    return {
        "cleaned_content": toned,
        "current_word_count": len(toned.split()),
        "next_step": "EDIT_SEQUENCE",
    }


# ============================================================
# EDIT
# ============================================================

async def edit_sequence_node(state: RefineGraphState, config: RunnableConfig):
    if not state.apply_edit:
        return {"next_step": "VALIDATE"}

    print("\n[EDIT_SEQUENCE]")

    llm = config["configurable"]["llm_service"]
    source = _get_latest_text(state)

    messages = [
        {
            "role": "system",
            "content": (
                "Improve clarity and grammar.\n"
                "NO content addition or removal."
            ),
        },
        {"role": "user", "content": source},
    ]

    edited = await llm.chat_completion(messages)

    return {
        "final_output": edited,
        "current_word_count": len(edited.split()),
        "next_step": "VALIDATE",
    }


# ============================================================
# TRIM
# ============================================================

async def expand_trim_node(state: RefineGraphState, config: RunnableConfig):
    print("\n[EXPAND_TRIM]")

    llm = config["configurable"]["llm_service"]

    messages = [
        {
            "role": "system",
            "content": f"Reduce to EXACTLY {state.hard_target_word_count} words.",
        },
        {"role": "user", "content": _get_latest_text(state)},
    ]

    trimmed = await llm.chat_completion(messages)

    return {
        "final_output": trimmed,
        "current_word_count": len(trimmed.split()),
        "trim_applied": True,
        "next_step": "VALIDATE",
    }


# ============================================================
# COMPRESS
# ============================================================

async def compress_enforce_node(state: RefineGraphState, config: RunnableConfig):
    print("\n[COMPRESS]")

    llm = config["configurable"]["llm_service"]

    messages = [
        {
            "role": "system",
            "content": f"Compress to EXACTLY {state.hard_target_word_count} words.",
        },
        {"role": "user", "content": state.cleaned_content},
    ]

    compressed = await llm.chat_completion(messages)

    return {
        "final_output": compressed,
        "current_word_count": len(compressed.split()),
        "next_step": "VALIDATE",
    }


# ============================================================
# VALIDATE (HARD GATE)
# ============================================================

def validate_node(state: RefineGraphState):
    print("\n[VALIDATE]")

    wc = len(_get_latest_text(state).split())
    target = state.hard_target_word_count

    if wc == target:
        return {
            "next_step": "SUGGESTIONS_ONLY"
            if state.apply_suggestions
            else "COMPLETE"
        }

    if state.is_expand and wc > target and not state.trim_applied:
        return {"next_step": "EXPAND_TRIM"}

    if state.retry_count >= state.max_retries:
        return {
            "warnings": [f"Ended at {wc} words (target {target})"],
            "next_step": "FAIL",
        }

    return {
        "retry_count": state.retry_count + 1,
        "next_step": "EXPAND_GROW" if state.is_expand else "COMPRESS_ENFORCE",
    }


# ============================================================
# SUGGESTIONS
# ============================================================

async def suggestions_node(state: RefineGraphState, config: RunnableConfig):
    print("\n[SUGGESTIONS_ONLY]")

    llm = config["configurable"]["llm_service"]

    messages = [
        {
            "role": "system",
            "content": "Provide improvement suggestions ONLY. Do not rewrite.",
        },
        {"role": "user", "content": state.final_output},
    ]

    suggestions = await llm.chat_completion(messages)
    return {"suggestions": suggestions}


# ============================================================
# BUILD GRAPH
# ============================================================

def build_refine_graph():
    graph = StateGraph(RefineGraphState)

    graph.add_node("PLANNER", planner_node)
    graph.add_node("SEMANTIC_CLEAN", semantic_clean_node)
    graph.add_node("RESEARCH_ENRICH", research_enrich_node)
    graph.add_node("EXPAND_GROW", expand_grow_node)
    graph.add_node("TONE_ADJUST", tone_adjust_node)
    graph.add_node("EDIT_SEQUENCE", edit_sequence_node)
    graph.add_node("EXPAND_TRIM", expand_trim_node)
    graph.add_node("COMPRESS_ENFORCE", compress_enforce_node)
    graph.add_node("VALIDATE", validate_node)
    graph.add_node("SUGGESTIONS_ONLY", suggestions_node)

    graph.set_entry_point("PLANNER")

    graph.add_edge("PLANNER", "SEMANTIC_CLEAN")
    graph.add_edge("SEMANTIC_CLEAN", "RESEARCH_ENRICH")
    graph.add_edge("RESEARCH_ENRICH", "EXPAND_GROW")
    graph.add_edge("EXPAND_GROW", "TONE_ADJUST")
    graph.add_edge("TONE_ADJUST", "EDIT_SEQUENCE")
    graph.add_edge("EDIT_SEQUENCE", "VALIDATE")
    graph.add_edge("EXPAND_TRIM", "VALIDATE")
    graph.add_edge("COMPRESS_ENFORCE", "VALIDATE")
    graph.add_edge("SUGGESTIONS_ONLY", END)

    graph.add_conditional_edges(
        "VALIDATE",
        lambda s: s.next_step,
        {
            "EXPAND_GROW": "EXPAND_GROW",
            "EXPAND_TRIM": "EXPAND_TRIM",
            "COMPRESS_ENFORCE": "COMPRESS_ENFORCE",
            "SUGGESTIONS_ONLY": "SUGGESTIONS_ONLY",
            "COMPLETE": END,
            "FAIL": END,
        },
    )

    return graph.compile()


# ============================================================
# PUBLIC API
# ============================================================

async def run_refine_content_graph(*, original_content, services, llm_service):
    graph = build_refine_graph()

    state = RefineGraphState(
        original_content=original_content,
        services=services,
    )

    result = await graph.ainvoke(
        state,
        config={"configurable": {"llm_service": llm_service}},
    )

    return {
        "content": result.get("final_output"),
        "suggestions": result.get("suggestions"),
        "word_count": result.get("current_word_count"),
        "warnings": result.get("warnings", []),
        "success": result.get("next_step") == "COMPLETE",
    }
