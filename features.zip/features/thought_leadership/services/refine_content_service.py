from app.infrastructure.llm.base_services import BaseTLStreamingService
import logging
import json
from typing import Any

from app.features.thought_leadership.services.refine_content.graph import (
    run_refine_content_graph
)

logger = logging.getLogger(__name__)


class RefineContentService(BaseTLStreamingService):
    """
    Thin orchestration layer.
    ALL intelligence lives in LangGraph.
    """

    async def refine_content(self, request_data: dict[str, Any]):
        original_content = request_data.get("original_content", "").strip()
        services = request_data.get("services", [])

        if not original_content:
            yield f"data: {json.dumps({'type': 'error', 'error': 'Original content is required'})}\n\n"
            return

        logger.info("[RefineContent] Executing LangGraph")

        result = await run_refine_content_graph(
            original_content=original_content,
            services=self._parse_services(services),
            llm_service=self.llm_service,
        )

        yield f"data: {json.dumps({'type': 'content', 'content': result['content']})}\n\n"

        if result.get("suggestions"):
            yield f"data: {json.dumps({'type': 'suggestions', 'content': result['suggestions']})}\n\n"

        if result.get("warnings"):
            yield f"data: {json.dumps({'type': 'warning', 'warnings': result['warnings']})}\n\n"

    def _parse_services(self, services_list):
        """
        Minimal normalized structure for LangGraph.
        """
        services = {
            "requested_word_limit": None,
            "is_expand": False,
            "tone": None,
            "research": False,
            "edit": False,
            "suggestions": False,
            "pwc_research_doc": None,   # ✅ PATCH
        }

        for s in services_list:
            if not s.get("isSelected"):
                continue

            t = s.get("type", "").lower()

            if t == "expand":
                services["requested_word_limit"] = s.get("expected_word_count")
                services["is_expand"] = True

            if t == "compress":
                services["requested_word_limit"] = s.get("expected_word_count")
                services["is_expand"] = False

            if t == "adjust_audience_tone":
                services["tone"] = s.get("audience_tone")

            if t == "enhanced_with_research":
                services["research"] = True

                pwc = s.get("pwc_content", {})
                if pwc.get("isSelected") and pwc.get("supportingDoc"):
                    services["pwc_research_doc"] = pwc["supportingDoc"]

            if t == "edit_content":
                services["edit"] = True

            if t == "improvement_suggestions":
                services["suggestions"] = True

        return services

    async def execute(self, *args, **kwargs):
        return await self.refine_content(*args, **kwargs)
