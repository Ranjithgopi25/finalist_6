"""
Web Search Service for Thought Leadership
Performs web searches and validates URLs for citations in articles
"""
import httpx
import logging
from typing import List, Dict, Optional
from urllib.parse import urlparse, quote_plus
import asyncio
from bs4 import BeautifulSoup
import re
import tavily
import os
from dotenv import load_dotenv

load_dotenv(".env", override=True)
logger = logging.getLogger(__name__)


class WebSearchService:
    """Service for performing web searches and validating URLs"""
    
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
    
    async def search_topic(self, topic: str, max_results: int = 10) -> List[Dict[str, str]]:
        """
        Perform web search for a topic and return validated results
        
        Args:
            topic: The topic to search for
            max_results: Maximum number of results to return
            
        Returns:
            List of dictionaries with 'title', 'url', and 'snippet' keys
        """
        logger.info(f"[WebSearch] Searching for topic: {topic}")
        
        #search_results = await self._tavily_search(topic, max_results)
        search_results = await self._duckduckgo_search(topic, max_results)
        validated_results = await self._validate_urls(search_results)
        
        logger.info(f"[WebSearch] Found {len(validated_results)} validated results")
        return validated_results
    
    # async def _tavily_search(self, query: str, max_results: int) -> List[Dict[str, str]]:
    #     """
    #     Perform search using Tavily AI search API
    #     """
    #     try:
    #         api_key = os.getenv("TAVILY_API_KEY")
    #         if not api_key:
    #             logger.error("[WebSearch] TAVILY_API_KEY not found in environment")
    #             return []
            
    #         client = tavily.TavilyClient(api_key=api_key)
    #         response = client.search(
    #             query=query,
    #             max_results=max_results * 2,  # Request more to account for filtering
    #             search_depth="basic",  # Options: "basic" or "advanced"
    #             include_answer=False,  # We only need search results
    #             include_raw_content=False  # We don't need full page content
    #         )
            
    #         results = []
            
    #         for result in response.get('results', []):
    #             try:
    #                 title = result.get('title', '')
    #                 url = result.get('url', '')
    #                 snippet = result.get('content', '')  
                    
    #                 if not title or not url:
    #                     continue
                    
    #                 if self._is_competitor_site(url):
    #                     logger.debug(f"[WebSearch] Filtered competitor site: {url}")
    #                     continue
                    
    #                 results.append({
    #                     'title': title,
    #                     'url': url,
    #                     'snippet': snippet
    #                 })
                    
    #                 if len(results) >= max_results:
    #                     break
                
    #             except Exception as e:
    #                 logger.warning(f"[WebSearch] Error parsing Tavily result: {e}")
    #                 continue
            
    #         logger.info(f"[WebSearch] Tavily returned {len(results)} results")
    #         return results
        
    #     except Exception as e:
    #         logger.error(f"[WebSearch] Tavily search failed: {e}")
    #         return []

    async def _duckduckgo_search(self, query: str, max_results: int) -> List[Dict[str, str]]:
        """
        Perform search using DuckDuckGo HTML interface
        """
        try:
            encoded_query = quote_plus(query)
            url = f"https://html.duckduckgo.com/html/?q={encoded_query}"
            
            async with httpx.AsyncClient(timeout=self.timeout, headers=self.headers, follow_redirects=True) as client:
                response = await client.get(url)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.text, 'html.parser')
                results = []
                
                # Parse DuckDuckGo results
                for result_div in soup.find_all('div', class_='result', limit=max_results * 2):
                    try:
                        # Extract title
                        title_elem = result_div.find('a', class_='result__a')
                        if not title_elem:
                            continue
                        
                        title = title_elem.get_text(strip=True)
                        
                        # Extract URL
                        url_elem = result_div.find('a', class_='result__url')
                        if not url_elem:
                            continue
                        
                        url = url_elem.get('href')
                        if not url or not url.startswith('http'):
                            # Try to construct URL from text
                            url_text = url_elem.get_text(strip=True)
                            if url_text and not url_text.startswith('http'):
                                url = f"https://{url_text}"
                            elif url_text:
                                url = url_text
                            else:
                                continue
                        
                        # Extract snippet
                        snippet_elem = result_div.find('a', class_='result__snippet')
                        snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""
                        
                        # Filter out competitor sites
                        if self._is_competitor_site(url):
                            #logger.info(f"[WebSearch] Filtered competitor site: {url}")
                            continue
                        
                        results.append({
                            'title': title,
                            'url': url,
                            'snippet': snippet
                        })
                        
                        if len(results) >= max_results:
                            break
                    
                    except Exception as e:
                        logger.warning(f"[WebSearch] Error parsing result: {e}")
                        continue
                
                logger.info(f"[WebSearch] DuckDuckGo returned {len(results)} results")
                return results
        
        except Exception as e:
            logger.error(f"[WebSearch] DuckDuckGo search FAILED - {type(e).__name__}: {str(e)}")
            logger.error(f"[WebSearch] This is likely due to network/SSL issues or DuckDuckGo blocking. Error details: {repr(e)}")
            return []

    
    
    async def _validate_urls(self, results: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """
        Validate URLs by making HEAD requests to check if they're accessible
        
        Args:
            results: List of search results with URLs
            
        Returns:
            Filtered list with only valid, accessible URLs
        """
        validated = []
        
        async with httpx.AsyncClient(timeout=self.timeout, headers=self.headers, follow_redirects=True) as client:
            validation_tasks = [
                self._validate_single_url(client, result)
                for result in results
            ]
            
            validation_results = await asyncio.gather(*validation_tasks, return_exceptions=True)
            
            for result, is_valid in zip(results, validation_results):
                if isinstance(is_valid, Exception):
                    logger.warning(f"[WebSearch] Validation error for {result['url']}: {is_valid}")
                    continue
                
                if is_valid:
                    validated.append(result)
        
        return validated
    
    async def _validate_single_url(self, client: httpx.AsyncClient, result: Dict[str, str]) -> bool:
        """
        Validate a single URL
        
        Args:
            client: HTTP client
            result: Search result dictionary
            
        Returns:
            True if URL is valid and accessible, False otherwise
        """
        try:
            url = result['url']
            
            # Basic URL validation
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                return False
            
            # Make HEAD request to check if URL is accessible
            response = await client.head(url, timeout=10)
            
            # Consider 2xx and 3xx as valid (including redirects)
            if response.status_code < 400:
                return True
            
            # If HEAD fails, try GET (some servers don't support HEAD)
            if response.status_code == 405:
                response = await client.get(url, timeout=10)
                return response.status_code < 400
            
            return False
        
        except Exception as e:
            logger.debug(f"[WebSearch] URL validation failed for {result.get('url', 'unknown')}: {e}")
            return False
    
    def _is_competitor_site(self, url: str) -> bool:
        """
        Check if URL is from a competitor site (Deloitte, McKinsey, EY, KPMG, BCG)
        
        Args:
            url: URL to check
            
        Returns:
            True if URL is from a competitor, False otherwise
        """
        competitor_domains = [
            'deloitte.com',
            'mckinsey.com',
            'ey.com',
            'kpmg.com',
            'bcg.com'
        ]
        
        try:
            parsed = urlparse(url.lower())
            domain = parsed.netloc
            
            # Remove 'www.' prefix if present
            if domain.startswith('www.'):
                domain = domain[4:]
            
            return any(comp_domain in domain for comp_domain in competitor_domains)
        
        except Exception:
            return False
    
    def format_citations(self, results: List[Dict[str, str]]) -> str:
        """
        Format search results as citations for inclusion in article
        
        Args:
            results: List of validated search results
            
        Returns:
            Formatted citations string
        """
        if not results:
            return ""
        
        citations = []
        for idx, result in enumerate(results, 1):
            citation = f"{idx}. {result['title']} (URL: {result['url']})"
            citations.append(citation)
        
        return "\n".join(citations)
    
    async def search_and_format(self, topic: str, max_results: int = 10) -> Dict[str, any]:
        """
        Perform search and return both raw results and formatted citations
        
        Args:
            topic: Topic to search for
            max_results: Maximum number of results
            
        Returns:
            Dictionary with 'results' and 'formatted_citations' keys
        """
        results = await self.search_topic(topic, max_results)
        formatted = self.format_citations(results)
        
        return {
            'results': results,
            'formatted_citations': formatted,
            'count': len(results)
        }
        
    