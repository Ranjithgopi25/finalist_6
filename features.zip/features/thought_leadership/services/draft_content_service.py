from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.web_search_service import WebSearchService
from app.common.factiva_client import FactivaClient
from typing import AsyncGenerator, List, Optional, Dict, Any
import logging
import re
import json

logger = logging.getLogger(__name__)

# ============================================================================
# SHARED PROMPT COMPONENTS - Extracted to eliminate duplication
# ============================================================================

ANTI_FABRICATION_RULES = """### **ANTI-FABRICATION RULES** (MANDATORY):
- Do NOT invent statistics, percentages, dates, case studies, company claims, research findings, or expert quotes.
- Do NOT mention any report, survey, whitepaper, or study unless it exists.
- If no real data is available, speak generically (e.g., "many companies," "some industries," "a growing trend").
- Do NOT attribute ideas to specific companies unless they are well-known, verifiable examples. When unsure, write more generally.
- **COMPETITOR PROHIBITION (CRITICAL):** Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from Deloitte, McKinsey, EY, KPMG, or BCG — under ANY circumstances. Use ONLY PwC sources, methodologies, and case studies."""

PARAGRAPH_CITATIONS = """### **PARAGRAPH-LEVEL REFERENCES (CRITICAL)**
- **Citations must be placed INLINE at the end of the last sentence of each paragraph, NOT on a separate line.**
- **ONLY use citation numbers that match the sources provided below. Do NOT invent or add citation numbers beyond what is provided.**
- Use the format: **(Ref. 1)**, **(Ref. 2)**, etc.
- Each citation must correspond to a real source in the "Citations & References" section below.
- If multiple references inform a paragraph, list them as: **(Ref. 1; Ref. 3)**."""

BRAND_ALIGNMENT_EDITOR = """### **BRAND ALIGNMENT EDITOR Instructions**

    ### ROLE
    You ensure content strictly follows PwC brand: voice, terminology, territory references, visual identity, and messaging framework.

    ---

    ### VOICE AND TONE

    **Collaborative:**
    - Use "we/our/us" not "PwC" for the firm.
    - Use "you/your organization" not "clients".
    - Use conversational tone with contractions.

    **Bold:**
    - Use assertive, decisive language.
    - Remove unnecessary qualifiers.
    - Use short, direct sentences.

    **Optimistic:**
    - Prefer active voice.
    - Future-forward, outcome-focused.
    - Use action verbs: transform, unlock, accelerate, adapt, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transition, etc.

    ---

    ### PROHIBITED TERMS / STYLE

    - Do **not** use:
      - "catalyst" or "catalyst for momentum" → use "driver", "enabler", "accelerator".
      - "PwC Network" → "PwC network" (lowercase n).
      - "clients" when "you/your organization" works.
      - Emojis in professional content.
      - ALL CAPS for emphasis (only for acronyms).
      - Exclamation marks in headlines, subheads, or body copy.

    ---

    ### CHINA & TERRITORIES (LEGAL – STRICT)

    **Correct usage:**
    - "PwC China" (not "PwC China/Hong Kong").
    - "Hong Kong SAR", "Macau SAR".
    - "Chinese Mainland" (not "Mainland China").
    - Office references: "PwC China, Beijing Office", "PwC China, Hong Kong Office", etc.
    - Use "PwC China", "PwC Hong Kong", "PwC Macau" when referring to a single territory.
    - Use "Countries/Regions" or "Countries and Regions" where appropriate.
    - Use "Territory" in the context of PwC network/member firms.

    **Prohibited usage:**
    - "PwC China/Hong Kong" or variants.
    - "Mainland China" → use "Chinese Mainland".
    - "Greater China" (external use).
    - "PRC" (external use).
    - "CaTSH" (internal only).

    **Geographic references:**
    - You may reference "Chinese Mainland" and "Hong Kong" together, but never imply the same status.
    - Reflect that Hong Kong is a Special Administrative Region within China.

    ---

    ### BRAND POSITIONING & MESSAGING

    **Catalyst for Momentum (brand idea):**
    - Embody it through tone and vocabulary.
    - Do **not** use the word "catalyst" or phrase "catalyst for momentum".

    **Messaging framework:**
    - Use network-wide key messages (explicitly or implicitly).
    - Support with proof points (data, examples, case studies) where appropriate.
    - Ensure local legal/risk approval before using proof points.

    **"So you can":**
    - Reserved mainly for primary surfaces (e.g. paid ads, key headlines, key sign-offs).
    - Structure: "We [capabilities] so you can [outcomes]."
    - Use sparingly to protect impact (don't overuse).

    ---

    ### BRAND VOCABULARY (INFUSE, DON'T FORCE)

    **Movement words (examples):**
    adapt, break through, disrupt, evolve, modernize, reconfigure, redefine, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transform, transition, unlock.

    **Energy words (examples):**
    act decisively, agile, anticipate, build, create, deliver, fast-track, forward-thinking, lay foundations, lead, move forward, navigate, propel, spot, surge.

    **Pace / outcome words (examples):**
    achieve, act, capitalize, drive, embrace resilience, further/faster, seize, accelerate progress, breakthrough results, build trust, gain competitive advantage, unlock value.

    Use combinations that feel natural and on-brand.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Apply **every** brand rule systematically.
    2. Enforce voice, terminology, geography, and positioning.
    3. Ensure strict legal compliance for China references.
    4. Preserve meaning while fixing brand violations.
    5. Flag all prohibited terms and replace with allowed alternatives."""

COPY_EDITOR_RULES = """## COPY EDITOR (IMPORTANT)

    ### ROLE
    You enforce PwC copy standards: punctuation, capitalization, spelling, abbreviations, numbers, dates, formats, and style consistency.

    Apply rules systematically to the full text while preserving meaning.

    ---

    ### KEY RULES (GROUPED)

    #### Abbreviations, Acronyms, All Caps
    - Use Oxford/Oxford Learner's Dictionary for standard abbreviations.
    - Acronyms: all caps (CEO, ESG, AI, B2B); exceptions: PwC, xLOS.
    - First use: spell out then acronym in brackets unless in OED (e.g. artificial intelligence (AI)).
    - Don't create new acronyms.
    - All caps only for acronyms or trademarked names (IDEO); never for emphasis.

    #### Spelling – American English
    - Use US English: -ize/-yze; -ization; -or (color), -er (center), -se nouns (license, defense).

    #### Contractions
    - Use contractions in most marketing, digital, internal, thought leadership, and speeches.
    - Avoid in formal/legal/sensitive documents.

    #### Numbers / Percentages
    - Percentages: always numerals + "%", no space ("5%", not "five percent").
    - Use commas in numbers 1,000+.
    - Large numbers: numerals + "million"/"bn" or "m"/"bn" (lowercase), consistent.

    #### PwC References
    - Write "PwC network" (lowercase n).
    - Don't capitalize generic descriptions ("network").

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Apply all relevant rules systematically.
    2. Check punctuation, capitalization, formatting, and style.
    3. Ensure consistency in numbers, dates, abbreviations, and terminology.
    4. Preserve meaning while correcting style and format."""

LINE_EDITOR_RULES = """## LINE EDITOR (IMPORTANT)

    ### ROLE
    You improve sentence-level clarity, correctness, consistency, and tone.

    **Boundaries (do NOT do):**
    - No restructuring sections or reordering major ideas.
    - No evaluating insight strength or evidence.
    - No detailed punctuation/formatting fixes.
    - No brand voice policing.

    You work **only** at sentence and wording level.

    ---

    ### OBJECTIVES

    1. Strengthen clarity and readability.
    2. Ensure correct grammar, usage, and voice.
    3. Align with PwC tone: clear, active, human, direct.
    4. Use inclusive, gender-neutral language.
    5. Enforce consistent terminology and style.
    6. Preserve intent while tightening execution.

    ---

    ### KEY RULES

    #### Active vs passive
    - Prefer active voice.
    - Convert passive where possible without changing meaning.

    #### Fewer vs less
    - Fewer = countable (fewer meetings, errors, people).
    - Less = uncountable (less time, noise, complexity).

    #### Point of view
    - Use "we/our/us" for the firm when appropriate.
    - Use "you/your" to address the reader directly.

    #### Gender neutrality
    - Use "they" for unspecified individuals.
    - Avoid gendered nouns (chairman → chairperson).

    #### Sentence length
    - One clear idea per sentence.
    - Break long, multi-clause sentences into shorter ones.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Output **only revised text**, no commentary.
    2. Preserve meaning while improving expression.
    3. Apply these rules consistently.
    4. Do not invent content—only refine what exists."""

CONTENT_EDITOR_RULES = """## CONTENT EDITOR (CRITICAL)

    ### ROLE
    You evaluate and strengthen the **insights, logic, and objective fit** of the content while preserving the author's core intent and voice.

    You focus on: insight strength, alignment with objectives, language that supports those objectives, evidence quality, structure, and MECE logic.

    ---

    ### OBJECTIVES

    1. **Evaluate insight strength and clarity**
      - Are insights specific, actionable, and clearly stated?
      - Are key insights prominent and easy to find?

    2. **Assess against content objectives**
      - Identify stated or implied objectives.
      - Check whether structure and content actually deliver on them.
      - Flag gaps between promise and delivery.

    3. **Refine language for objective alignment**
      - Preserve voice.
      - Strengthen language that supports objectives.
      - Remove or revise language that dilutes or contradicts objectives.

    4. **Ensure logical rigor and evidence quality**
      - Support significant claims with data, examples, or reasoning.
      - Remove or tighten weak or vague claims.
      - Maintain MECE structure where applicable.

    ---

    ### KEY RULES

    #### Insight evaluation
    - Strong insights are: Clear, specific, actionable, supported by evidence or solid reasoning, positioned where they have maximum impact.
    - Weak insights: Vague, generic or unsupported, hidden in dense text.

    #### Evidence and support
    - Every meaningful claim needs appropriate support: Data, stats, surveys, reputable sources or expert opinions, case examples, clear logic.

    #### Logical structure and flow
    - Ensure: Clear intro, logical progression of ideas, smooth transitions between sections, strong conclusion.
    - Remove: Logical fallacies, redundant or conflicting points.

    #### MECE organization
    - Sections and categories should be: Mutually exclusive (no overlap in content scope), collectively exhaustive (cover all relevant aspects).

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Evaluate insight strength and clarity across the whole piece.
    2. Assess and note alignment with content objectives.
    3. Refine language to better serve those objectives while preserving voice.
    4. Check evidence sufficiency and logical structure.
    5. Preserve intent while increasing clarity and impact.
    6. Flag issues with specific examples, rule references, and clear fixes where needed."""

DEVELOPMENT_EDITOR_RULES = """## DEVELOPMENT EDITOR (CRITICAL)

    ### ROLE
    You transform content at the **structure and narrative** level while enforcing PwC's tone: **Bold, Collaborative, Optimistic**.

    You diagnose and fix clarity, structure, logic, and flow problems. You do not hedge, praise, or apologize.

    ---

    ### TONE OF VOICE (ALWAYS USE ALL THREE)

    #### Bold
    - Use decisive, assertive language; remove soft qualifiers.
    - Cut jargon and filler; keep sentences tight.
    - Use rhythm and emphasis through structure, not exclamation marks.

    #### Collaborative
    - Write conversationally.
    - Use "we" and "you" to emphasize partnership: "We help you…" not "PwC helps organizations…".
    - Ask sharp, relevant questions that invite reflection.

    #### Optimistic
    - Use active voice and clear calls to action.
    - Show opportunity beyond challenge.
    - Use positive but realistic language supported by data.

    ---

    ### WHAT YOU CHANGE

    #### A. Structure
    - Reorder or regroup content for stronger logic.
    - Break long paragraphs.
    - Strengthen openings and conclusions.
    - Ensure each section supports one clear idea.

    #### B. Clarity
    - Replace vague claims with precise statements.
    - Remove ambiguity and contradictions.
    - Cut unnecessary detail that doesn't advance the message.

    #### C. Purpose alignment
    - Identify: Core message, priority takeaways, desired actions or mindset shift.
    - Rewrite so structure and emphasis serve that purpose.

    #### D. Language discipline
    - Short, direct sentences.
    - Simple transitions.
    - No clichés, filler, or unnecessary corporate jargon.
    - No poetic or ornamental phrasing.

    #### E. Brutal accuracy
    - Call out weak reasoning and unrealistic claims.
    - Tighten or remove hype.
    - Strengthen arguments with clearer logic and framing.

    ---

    ### CONSTRAINTS

    - No praise of the original text.
    - No process explanations or apologies.
    - No exclamation marks.
    - No generic motivational language.
    - Don't write "PwC helps organizations…": always "we".
    - Avoid filler (e.g. "in order to", "at the end of the day", "moving forward", "leverage" used as a buzzword).
    - Avoid lofty promises ("guaranteed", "transformational", "revolutionary") unless explicitly backed by evidence.
    - Tone must always remain **Bold + Collaborative + Optimistic** at the same time.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Diagnose structural and narrative issues.
    2. Provide specific, actionable feedback.
    3. Rewrite for maximum clarity and impact.
    4. Enforce Bold + Collaborative + Optimistic tone throughout.
    5. Do not praise or apologize."""

# Format-specific configurations
_FORMAT_CONFIGS = {
    'blog': {
        'intro': 'You are an expert blog content writer for PwC thought leadership — able to turn complex business/industry insights into engaging, reader-friendly blog posts that nonetheless carry credibility, clarity, and strategic value.',
        'tone': 'Conversational yet professional (fit for thought leadership, but approachable)',
        'word_limit': 1500,
        'tolerance': 10,
        'sentence_min': 14,
        'sentence_max': 18,
        'body_structure': '3–5 main sections, Key Takeaways, Conclusion',
    },
    'executive_brief': {
        'intro': 'You are an expert executive brief writer for PwC thought-leadership: skilled at distilling complex information into sharp, actionable summaries for senior executives.',
        'tone': 'Professional and authoritative yet accessible',
        'word_limit': 500,
        'tolerance': 2,
        'sentence_min': 12,
        'sentence_max': 16,
        'body_structure': 'Overview, Key Insights, Business Implications, Recommended Actions, Closing',
    },
    'whitepaper': {
        'intro': 'You are an expert white paper writer for PwC thought-leadership: authoritative, research-driven, and deeply analytical.',
        'tone': 'Authoritative, research-driven, deeply analytical',
        'word_limit': 4000,
        'tolerance': 10,
        'sentence_min': 18,
        'sentence_max': 24,
        'body_structure': 'Cover, Executive Summary, Introduction, Foundational Concepts, Market Landscape, Detailed Analysis, Implementation, Risks, Future Outlook, Conclusion, Appendices',
    },
    'article': {
        'intro': 'You are an expert article writer for PwC thought leadership — creating authoritative, research-driven, and analytical content.',
        'tone': 'Authoritative, research-driven, highly analytical',
        'word_limit': 2000,
        'tolerance': 10,
        'sentence_min': 14,
        'sentence_max': 18,
        'body_structure': 'Title, Introduction, 4-6 Main Body Sections, Conclusion, Citations',
    },
}


class Source:
    """
    Represents a research source (Factiva article, URL, etc.) for citation tracking.
    """
    def __init__(self, id: int, url: str, title: str = "", content: str = "", byline: str = "", publication_date: str = "", source_name: str = ""):
        self.id = id
        self.url = url
        self.title = title
        self.content = content
        self.byline = byline
        self.publication_date = publication_date
        self.source_name = source_name


class DraftContentService(BaseTLStreamingService):
    """Service for draft content generation workflow with Factiva research integration"""
    
    def __init__(self, llm_service, factiva_client: Optional[FactivaClient] = None):
        """
        Initialize Draft Content Service
        
        Args:
            llm_service: LLM service
            factiva_client: Optional Factiva client for research sources
        """
        super().__init__(llm_service)
        self.web_search_service = WebSearchService()
        self.factiva_client = factiva_client
    
    def _build_prompt(
        self,
        format_type: str,
        topic: str,
        audience: str,
        word_limit: int,
        outline_doc: str,
        supporting_doc: str,
        citations_text: str
    ) -> str:
        """
        Build complete system prompt by combining shared components with format-specific config.
        
        Args:
            format_type: 'blog', 'executive_brief', 'whitepaper', or 'article'
            topic, audience, word_limit, outline_doc, supporting_doc: Content parameters
            citations_text: Pre-built citations from _build_unified_citations()
        
        Returns:
            Complete formatted system prompt string
        """
        config = _FORMAT_CONFIGS.get(format_type, _FORMAT_CONFIGS['blog'])
        
        # Build format-specific opening based on content type
        if format_type == 'blog':
            task_desc = f"""**Task:** Write a blog post on **"{topic}"**, for **{audience}**, targeting **approximately {word_limit} words** (± 2%). Your final output should be close to {word_limit} words in total — not a short summary, not a thin overview.  

If {outline_doc} is provided: use it as the structural roadmap.  
If {supporting_doc} is provided: draw from it — use its data, examples, or insights — but expand with additional context, recent developments (2023-2025 where relevant), and practical analysis."""
            
        elif format_type == 'executive_brief':
            task_desc = f"""**Your Task:**  
Create a professional, strategic executive brief on **"{topic}"**, tailored for **{audience}**, with a strict target length of **{word_limit} words** (± 2% — aim for {word_limit} words). The brief should be ready for delivery to senior leadership, requiring no further edits beyond formatting.

If {supporting_doc} is provided: base your brief strictly on the source material — extract core insights and distill main points.  
If {outline_doc} is provided: follow the outline structure mentioned in the document strictly as the roadmap — ensure every section is expanded sufficiently so that the entire brief meets exactly {word_limit} words."""
            
        elif format_type == 'whitepaper':
            task_desc = f"""**Task:** Write a full white paper on **{topic}**, tailored for **{audience}**, using **exactly {word_limit} words** — not a word more. The output must total **{word_limit} words in full** (excluding any appended metadata or comments).

If {supporting_doc} is provided, treat it as background and integrate relevant data, examples, or insights, updating where needed and enriching with additional current (2023–2025) research, quantified data, and real-world examples.

If {outline_doc} is provided, follow its structure strictly, but ensure that every section is expanded sufficiently so that the entire document meets exactly {word_limit} words."""
            
        else:  # article
            task_desc = f"""**Task:** Write a professional article on **"{topic}"**, for **{audience}**, targeting **approximately {word_limit} words** (± 2%). Your final output should be close to {word_limit} words in total.

If {outline_doc} is provided: use it as the structural roadmap.  
If {supporting_doc} is provided: draw from it — use its data, examples, or insights — but expand with additional context, recent developments (2023-2025 where relevant), and practical analysis."""
        
        # Build prompt template
        prompt = f"""{config['intro']}

{task_desc}

---
{ANTI_FABRICATION_RULES}

{PARAGRAPH_CITATIONS}

**Correct example:**
"The history of tariffs shows significant evolution over time **(Ref. 1)**."

**Incorrect example:**
"The history of tariffs shows significant evolution over time.

**(Ref. 1)**"

- **The Citations & References section must contain ONLY the sources provided below - do not add any additional sources from your knowledge.**
- **If no sources are provided below, write general analysis WITHOUT citations and WITHOUT a Citations & References section.**

## ✨ Writing Style & Quality Standards

- **Tone:** {config['tone']}
- **Sentence length:** {config['sentence_min']}-{config['sentence_max']} words per sentence
- **Key requirement:** Every sentence must fall within this range. Adjust length as needed.
- **Active voice preferred**
- **Clear, direct language**
- **Minimal jargon** (define when used)
- **Mix paragraph lengths** for readability
- **Support claims** with data, examples, or references
- **Maintain focus** on topic and audience
- **NEVER cite, reference, or use any content, methodologies, or case studies from Deloitte, McKinsey, EY, KPMG, or BCG.** Use ONLY PwC sources and case studies.

---

## ✅ Word-Count Guidance

- Target total ≈ {word_limit} words (±{config['tolerance']}% acceptable).  
- Trim redundant sentences if too long; don't remove key data or insight.
- Use shorter paragraphs and section-based structure.
- Dont mention word count explicitly in the output.

---

{BRAND_ALIGNMENT_EDITOR}

{COPY_EDITOR_RULES}

{LINE_EDITOR_RULES}

{CONTENT_EDITOR_RULES}

{DEVELOPMENT_EDITOR_RULES}

**Citations & References (BOLD REQUIRED)** 
- Include {citations_text} in this section, use those sources and include a "Citations & References" section at the end.
- Format each entry as:
1. [Source Title or Description] (URL: [full, verified, clickable URL])
"""
        return prompt
    
    async def fetch_factiva_sources(
        self, 
        query: str, 
        content_type: str,
        response_limits: Dict[str, int],
        language_filters: Optional[List[str]] = None
    ) -> List[Source]:
        """
        Fetch Factiva articles and convert to Source objects
        
        Args:
            query: Search query/topic
            content_type: Content type (article, blog, white_paper, executive_brief)
            response_limits: Dict with response limits per content type
            language_filters: Language filters (default: ["en", "de"])
        
        Returns:
            List of Source objects with full article content
        """
        if not self.factiva_client:
            logger.warning("[FACTIVA] Client not available - skipping research fetch")
            return []
        
        try:
            # Get response limit for this content type (convert to lowercase for lookup)
            content_type_key = content_type.lower().replace(" ", "_")
            response_limit = response_limits.get(content_type_key)
            
            if response_limit is None:
                logger.warning(f"[FACTIVA] Response limit for '{content_type_key}' not found in config. Available keys: {list(response_limits.keys())}. Using default of 5.")
                response_limit = 5
            
            logger.info(f"[FACTIVA] INVOKED: Fetching sources for query='{query}' (limit={response_limit}, type={content_type}, key={content_type_key})")
            logger.debug(f"[FACTIVA] Response limits config: {response_limits}")
            
            # Search Factiva
            logger.debug(f"[FACTIVA] Calling search_articles with language_filters={language_filters or ['en', 'de']}")
            factiva_articles = await self.factiva_client.search_articles(
                query=query,
                response_limit=response_limit,
                language_filters=language_filters or ["en", "de"]
            )
            
            logger.info(f"[FACTIVA] Search completed. Retrieved {len(factiva_articles)} articles from Factiva API")
            
            # Convert to Source objects
            sources = []
            for idx, article in enumerate(factiva_articles, 1):
                source = Source(
                    id=idx,
                    url=article.url,
                    title=article.title or article.headline,
                    content=article.content,  # Full article text
                    byline=article.byline or "",
                    publication_date=article.publication_date or article.load_date,
                    source_name=article.source_name
                )
                sources.append(source)
                logger.info(f"[FACTIVA] Source {idx}: '{source.title}' from {source.source_name}")
            
            logger.info(f"[FACTIVA] SUCCESS: Converted {len(sources)} Factiva articles to Source objects for content generation")
            return sources
        
        except Exception as e:
            logger.error(f"[FACTIVA] ERROR during search: {type(e).__name__}: {str(e)}")
            logger.info("[FACTIVA] FALLBACK: Continuing without Factiva research - will use outline/supporting docs only")
            return []
    
    async def _build_unified_citations(self, topic: str, max_web_results: int = 10, factiva_sources: Optional[List[Source]] = None) -> str:
        """
        Build a unified citations list that merges web search and Factiva sources
        
        Args:
            topic: Search topic for web search
            max_web_results: Maximum web search results to include
            factiva_sources: Optional list of Factiva Source objects
        
        Returns:
            Formatted citations text with unified numbering (1, 2, 3, ...)
        """
        all_citations = []
        citation_number = 1
        
        # Add Factiva sources first (prioritize authoritative research)
        if factiva_sources:
            logger.info(f"[CITATIONS] Adding {len(factiva_sources)} Factiva sources to unified citations list (starting from #{citation_number})")
            
            # Add Factiva compliance notice at the top
            factiva_notice = """=== FACTIVA USAGE RESTRICTIONS (CRITICAL - MUST FOLLOW) ===

When using Factiva sources, you MUST adhere to these licensing requirements:

1. VERBATIM TEXT LIMIT:
   - You may use a MAXIMUM of 50 words of verbatim text per Factiva article
   - Count every word you copy directly from the article
   - If you exceed 50 words from any single article, you are in violation

2. SUMMARY LENGTH LIMIT:
   - If your content is based on a SINGLE Factiva article, keep summaries UNDER 100 words total
   - This applies to the entire section/paragraph based on that article, not just quoted text

3. PARAPHRASING REQUIRED:
   - Beyond the 50-word verbatim limit, you MUST paraphrase and synthesize in your own words
   - Do not simply rearrange words from the original article
   - Add analytical value and insights rather than restating the article's content

IMPORTANT: These restrictions apply PER ARTICLE. If you use multiple Factiva sources, each has its own 50-word verbatim limit.

=== SOURCES FOR CITATION ===
"""
            all_citations.append(factiva_notice)
            
            for source in factiva_sources:
                # Format: Number. Title | Source | Date | By Author (URL: url)
                citation = f"{citation_number}. {source.title}"
                if source.source_name:
                    citation += f" | {source.source_name}"
                if source.publication_date:
                    citation += f" | {source.publication_date}"
                if source.byline:
                    citation += f" | By {source.byline}"
                if source.url:
                    citation += f" (URL: {source.url})"
                all_citations.append(citation)
                citation_number += 1
        
        # Add web search sources
        logger.info(f"[CITATIONS] Performing web search for topic: {topic}")
        web_search_data = await self.web_search_service.search_and_format(topic, max_results=max_web_results)
        
        if web_search_data['count'] > 0:
            logger.info(f"[CITATIONS] Adding {web_search_data['count']} web search sources to unified citations list (starting from #{citation_number})")
            
            # Parse web search citations and renumber them
            web_citations_raw = web_search_data['formatted_citations'].strip().split('\n')
            for web_citation in web_citations_raw:
                if web_citation.strip():
                    # Remove old numbering (e.g., "1. Title..." becomes "Title...")
                    citation_text = web_citation.strip()
                    if citation_text[0].isdigit() and '. ' in citation_text:
                        citation_text = citation_text.split('. ', 1)[1]
                    
                    # Add new unified numbering
                    all_citations.append(f"{citation_number}. {citation_text}")
                    citation_number += 1
        else:
            logger.warning(f"[CITATIONS] No web search results found for topic: {topic}")
        
        unified_citations = '\n'.join(all_citations)
        total_sources = citation_number - 1
        logger.info(f"[CITATIONS] Unified citations built: {total_sources} total sources ({len(factiva_sources or [])} Factiva + {web_search_data['count']} web)")
        
        return unified_citations

    async def draft_blog_system_prompt(self, user_prompt: str, topic: str, word_limit: int, audience: str, outline_doc: str, supporting_doc: str, use_factiva_research: bool = False, factiva_sources: Optional[List[Source]] = None) -> AsyncGenerator[str, None]:
        """Generate system prompt for creating blog content - engaging, accessible articles that educate and inspire action."""

        # Build unified citations list (Factiva + web search)
        logger.info(f"[Draft Blog] Building unified citations for topic: {topic} (Factiva={use_factiva_research}, sources={len(factiva_sources) if factiva_sources else 0})")
        citations_text = await self._build_unified_citations(
            topic=topic, 
            max_web_results=10, 
            factiva_sources=factiva_sources if use_factiva_research else None
        )

        system_prompt = self._build_prompt(
            format_type='blog',
            topic=topic,
            audience=audience,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc,
            citations_text=citations_text
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f"[DRAFT_BLOG] Starting blog content generation - target: {word_limit} words (±10%)")
        generated_content = await self.get_content(messages, max_tokens=30000)
        
        # Step 2: Validate word count
        logger.info(f"[DRAFT_BLOG] Validating word count...")
        validation_result = await self.validate_word_count(
            content=generated_content,
            word_limit=word_limit,
            tolerance_percent=10
        )
        
        # Step 3: If content doesn't meet word count requirements, recreate it
        if not validation_result['is_valid']:
            logger.info(f"[DRAFT_BLOG] Word count adjustment needed - {validation_result['status']}")
            
            # Recreate content with adjusted length and yield only the adjusted content
            async for chunk in self.recreate_content_with_adjusted_length(
                original_content=generated_content,
                validation_result=validation_result,
                topic=topic,
                audience=audience,
                outline_doc=outline_doc,
                supporting_doc=supporting_doc
            ):
                yield chunk
            
            logger.info(f"[DRAFT_BLOG] Content adjustment completed")
        else:
            logger.info(f"[DRAFT_BLOG] Content meets word count requirements - no adjustment needed")
            # Yield only the valid content
            # yield generated_content
            yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

    async def draft_executivebrief_system_prompt(self, user_prompt: str, topic: str, word_limit: int, audience: str, outline_doc: str, supporting_doc: str, use_factiva_research: bool = False, factiva_sources: Optional[List[Source]] = None) -> AsyncGenerator[str, None]:
        """Get system prompt for executive brief which is a short document that provides a high-level overview of a longer report, business plan, or proposal, intended for busy decision-makers."""

        # Build unified citations list (Factiva + web search)
        logger.info(f"[Draft Executive Brief] Building unified citations for topic: {topic} (Factiva={use_factiva_research}, sources={len(factiva_sources) if factiva_sources else 0})")
        citations_text = await self._build_unified_citations(
            topic=topic, 
            max_web_results=10, 
            factiva_sources=factiva_sources if use_factiva_research else None
        )

        system_prompt = self._build_prompt(
            format_type='executive_brief',
            topic=topic,
            audience=audience,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc,
            citations_text=citations_text
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f"[DRAFT_EXECUTIVEBRIEF] Starting executive brief content generation - target: {word_limit} words (±2%)")
        generated_content = await self.get_content(messages, max_tokens=30000)
        
        # Step 2: Validate word count
        logger.info(f"[DRAFT_EXECUTIVEBRIEF] Validating word count...")
        validation_result = await self.validate_word_count(
            content=generated_content,
            word_limit=word_limit,
            tolerance_percent=2
        )
        
        # Step 3: If content doesn't meet word count requirements, recreate it
        if not validation_result['is_valid']:
            logger.info(f"[DRAFT_EXECUTIVEBRIEF] Word count adjustment needed - {validation_result['status']}")
            
            async for chunk in self.recreate_content_with_adjusted_length(
                original_content=generated_content,
                validation_result=validation_result,
                topic=topic,
                audience=audience,
                outline_doc=outline_doc,
                supporting_doc=supporting_doc
            ):
                yield chunk
            
            logger.info(f"[DRAFT_EXECUTIVEBRIEF] Content adjustment completed")
        else:
            logger.info(f"[DRAFT_EXECUTIVEBRIEF] Content meets word count requirements - no adjustment needed")
            # yield generated_content
            yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

    async def draft_whitepaper_system_prompt(self, user_prompt: str, topic: str, word_limit: int, audience: str, outline_doc: str, supporting_doc: str, use_factiva_research: bool = False, factiva_sources: Optional[List[Source]] = None) -> AsyncGenerator[str, None]:
        """Get system prompt for white paper reporting"""

        # Build unified citations list (Factiva + web search)
        logger.info(f"[Draft Whitepaper] Building unified citations for topic: {topic} (Factiva={use_factiva_research}, sources={len(factiva_sources) if factiva_sources else 0})")
        citations_text = await self._build_unified_citations(
            topic=topic, 
            max_web_results=10, 
            factiva_sources=factiva_sources if use_factiva_research else None
        )

        system_prompt = self._build_prompt(
            format_type='whitepaper',
            topic=topic,
            audience=audience,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc,
            citations_text=citations_text
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f"[DRAFT_WHITEPAPER] Starting whitepaper content generation - target: {word_limit} words (±10%)")
        generated_content = await self.get_content(messages, max_tokens=30000)
        
        # Step 2: Validate word count
        logger.info(f"[DRAFT_WHITEPAPER] Validating word count...")
        validation_result = await self.validate_word_count(
            content=generated_content,
            word_limit=word_limit,
            tolerance_percent=10
        )
        
        # Step 3: If content doesn't meet word count requirements, recreate it
        if not validation_result['is_valid']:
            logger.info(f"[DRAFT_WHITEPAPER] Word count adjustment needed - {validation_result['status']}")
            
            async for chunk in self.recreate_content_with_adjusted_length(
                original_content=generated_content,
                validation_result=validation_result,
                topic=topic,
                audience=audience,
                outline_doc=outline_doc,
                supporting_doc=supporting_doc
            ):
                yield chunk
            
            logger.info(f"[DRAFT_WHITEPAPER] Content adjustment completed")
        else:
            logger.info(f"[DRAFT_WHITEPAPER] Content meets word count requirements - no adjustment needed")
            # yield generated_content
            
            yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"


    async def draft_article_system_prompt(self, user_prompt: str, topic: str, word_limit: int, audience: str, outline_doc: str, supporting_doc: str, use_factiva_research: bool = False, factiva_sources: Optional[List[Source]] = None) -> AsyncGenerator[str, None]:
        """Generate system prompt for creating article content - professional, authoritative articles."""

        # Build unified citations list (Factiva + web search)
        logger.info(f"[Draft Article] Building unified citations for topic: {topic} (Factiva={use_factiva_research}, sources={len(factiva_sources) if factiva_sources else 0})")
        citations_text = await self._build_unified_citations(
            topic=topic, 
            max_web_results=10, 
            factiva_sources=factiva_sources if use_factiva_research else None
        )

        system_prompt = self._build_prompt(
            format_type='article',
            topic=topic,
            audience=audience,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc,
            citations_text=citations_text
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f"[DRAFT_ARTICLE] Starting article content generation - target: {word_limit} words (±10%)")
        generated_content = await self.get_content(messages, max_tokens=30000)
        
        # Step 2: Validate word count
        logger.info(f"[DRAFT_ARTICLE] Validating word count...")
        validation_result = await self.validate_word_count(
            content=generated_content,
            word_limit=word_limit,
            tolerance_percent=10
        )
        
        # Step 3: If content doesn't meet word count requirements, recreate it
        if not validation_result['is_valid']:
            logger.info(f"[DRAFT_ARTICLE] Word count adjustment needed - {validation_result['status']}")
            
            async for chunk in self.recreate_content_with_adjusted_length(
                original_content=generated_content,
                validation_result=validation_result,
                topic=topic,
                audience=audience,
                outline_doc=outline_doc,
                supporting_doc=supporting_doc
            ):
                yield chunk
            
            logger.info(f"[DRAFT_ARTICLE] Content adjustment completed")
        else:
            logger.info(f"[DRAFT_ARTICLE] Content meets word count requirements - no adjustment needed")
            # yield generated_content
            yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

    async def draft_content_from_prompt(
        self, 
        user_prompt: str
    ) -> AsyncGenerator[str, None]:
        """Draft content from user's structured prompt"""
        
        system_prompt = """You are an expert content writer for PwC thought leadership.
Create comprehensive, high-quality professional content that demonstrates deep expertise and provides substantial value to readers.

Content Length Guidelines:
- Articles/White Papers: Aim for 1800-2000 words of in-depth analysis
- Blog Posts: Target 1300-1500 words with detailed insights
- Executive Briefs: 400-500 words of strategic content
- Unless user specifies a different length, default to comprehensive, thorough coverage

Writing Principles:
- Professional tone with authoritative insights backed by evidence
- Clear structure with compelling narrative flow
- Include relevant PwC frameworks and methodologies with detailed explanations
- Provide actionable recommendations with implementation guidance
- Use multiple data points, examples, and case studies to support arguments
- Develop each key point thoroughly with context, analysis, and implications
- Include real-world scenarios and practical applications

Content Structure:
- Article: Compelling hook → Comprehensive context → Multi-layered analysis → Detailed recommendations → Strong conclusion (3000-5000 words)
- Blog: Engaging opening → Multiple key points with examples → Real-world applications → Actionable takeaways (1500-2500 words)
- White Paper: Executive summary → Problem analysis → Comprehensive solution framework → Multiple case studies → Strategic recommendations (3000-5000 words)
- Executive Brief: Key insights with context → Strategic implications → Prioritized action items with rationale (1000-1500 words)

Remember: Thought leadership requires depth. Provide comprehensive coverage with rich insights, multiple perspectives, and thorough analysis."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        async for chunk in self.stream_response(messages):
            yield chunk

    async def draft_content(
        self, 
        topic: str, 
        format_type: str, 
        audience: str, 
        context: str
    ) -> AsyncGenerator[str, None]:
        """Draft content based on topic, format, and audience (legacy interface)"""
        
        user_prompt = f"Create a {format_type} about {topic} for {audience}."
        if context:
            user_prompt += f"\n\nAdditional context: {context}"
        
        async for chunk in self.draft_content_from_prompt(user_prompt):
            yield chunk
    
    async def execute(self, *args, **kwargs):
        """Execute draft content generation"""
        return await self.draft_content(*args, **kwargs)
    
    async def validate_word_count(self, content: str, word_limit: int, tolerance_percent: int = 10) -> dict:
        """
        Validate if the generated content word count is within acceptable limits using LLM.
        
        Args:
            content: Generated content to validate
            word_limit: Target word limit
            tolerance_percent: Acceptable deviation percentage (default: 10%)
        
        Returns:
            dict with keys:
                - word_count: Actual word count of the content
                - word_limit: Target word limit
                - tolerance_percent: Tolerance percentage
                - is_valid: Boolean indicating if content meets word count requirement
                - min_words: Minimum acceptable words (word_limit - tolerance)
                - max_words: Maximum acceptable words (word_limit + tolerance)
                - deviation: Actual deviation from target (positive = over, negative = under)
                - status: Status message ('VALID', 'TOO_SHORT', 'TOO_LONG')
        """
        logger.info(f"[WORD_COUNT_VALIDATION] Starting word count validation using regex")
        logger.info(f"[WORD_COUNT_VALIDATION] Content length: {len(content)} characters")
        logger.info(f"[WORD_COUNT_VALIDATION] Target word limit: {word_limit} (±{tolerance_percent}%)")
        
        # Regex-based word counting - use word boundaries to count actual words
        # Remove markdown formatting symbols first, then count words using regex
        normalized_content = content
        
        # Normalize newlines and whitespace
        normalized_content = re.sub(r'[\n\r\t]+', ' ', normalized_content)  # Replace newlines/tabs with spaces
        
        # Remove markdown formatting symbols (**, ##, ---, etc.) but keep content
        normalized_content = re.sub(r'\*\*', '', normalized_content)  # Remove **bold**
        normalized_content = re.sub(r'#+\s+', '', normalized_content)  # Remove ### headers
        normalized_content = re.sub(r'---+', '', normalized_content)  # Remove --- dividers
        normalized_content = re.sub(r'`+', '', normalized_content)  # Remove backticks
        normalized_content = re.sub(r'_{2,}', '', normalized_content)  # Remove underscores
        
        # Use regex word boundary to count words - includes contractions and hyphenated words
        # This pattern matches sequences of letters, digits, apostrophes, and hyphens
        word_pattern = r'\b[\w\'-]+\b'
        words = re.findall(word_pattern, normalized_content, re.UNICODE)
        
        # Filter out metadata keywords (case-insensitive)
        metadata_keywords = {'data', 'type', 'content'}
        filtered_words = [word for word in words if word.lower() not in metadata_keywords]
        
        word_count = len(filtered_words)
        logger.info(f"[WORD_COUNT_VALIDATION] Regex-based word count: {word_count} words (after removing metadata)")
        
        # Calculate tolerance range
        tolerance_words = int((word_limit * tolerance_percent) / 100)
        min_words = word_limit - tolerance_words
        max_words = word_limit + tolerance_words
        
        # Determine if content is valid
        is_valid = min_words <= word_count <= max_words
        
        # Calculate deviation
        deviation = word_count - word_limit
        
        # Determine status
        if is_valid:
            status = 'VALID'
        elif word_count < min_words:
            status = 'TOO_SHORT'
        else:
            status = 'TOO_LONG'
        
        logger.info(f"[WORD_COUNT_VALIDATION] Final validation result: {status} - {word_count} words (target: {word_limit})")
        
        return {
            'word_count': word_count,
            'word_limit': word_limit,
            'tolerance_percent': tolerance_percent,
            'is_valid': is_valid,
            'min_words': min_words,
            'max_words': max_words,
            'deviation': deviation,
            'status': status
        }
    
    async def recreate_content_with_adjusted_length(
        self,
        original_content: str,
        validation_result: dict,
        topic: str,
        audience: str,
        outline_doc: str = "",
        supporting_doc: str = ""
    ) -> AsyncGenerator[str, None]:
        """
        Recreate and adjust content to meet word count requirements.
        
        If content is too long, compress it while maintaining key insights.
        If content is too short, expand it with more details and examples.
        
        Args:
            original_content: The original generated content
            validation_result: Result from validate_word_count()
            topic: Topic of the content
            audience: Target audience
            outline_doc: Optional outline document for reference
            supporting_doc: Optional supporting document for reference
        
        Yields:
            Adjusted content chunks
        """
        word_count = validation_result['word_count']
        word_limit = validation_result['word_limit']
        status = validation_result['status']
        
        logger.info(f"[CONTENT_RECREATION] Starting content adjustment: status={status}, current_words={word_count}, target_words={word_limit}")
        
        if status == 'TOO_LONG':
            action_prompt = f"""The generated content has {word_count} words, but the target is {word_limit} words.
            
Please COMPRESS and condense the content to approximately {word_limit} words while:
1. Preserving all key insights and main arguments
2. Removing redundant examples or explanations
3. Tightening paragraph structures
4. Keeping important data points and evidence
5. Maintaining the overall structure (Title, Intro, Body sections, Key Takeaways, Conclusion, Citations)

Ensure all section headers remain in bold (**Header**) format.

Original content to compress:

{original_content}"""
        
        else:  # TOO_SHORT
            action_prompt = f"""The generated content has only {word_count} words, but the target is {word_limit} words.

Please EXPAND and enrich the content to approximately {word_limit} words by:
1. Adding more detailed analysis and context to existing sections
2. Including additional real-world examples, case studies, or scenarios
3. Expanding key insights with deeper explanations
4. Adding implementation guidance or practical considerations
5. Enhancing the introduction and conclusion with more substance
6. Including relevant data points, statistics, or research findings (if factual and verifiable)

Ensure all section headers remain in bold (**Header**) format.
Do NOT add fabricated data or unverifiable claims.

Original content to expand:

{original_content}"""
        
        logger.debug(f"[CONTENT_RECREATION] Prompting LLM for {status.lower()} adjustment")
        
        system_prompt = """You are an expert content editor specializing in PwC thought leadership. 
Your task is to adjust content length while maintaining quality, clarity, and impact.

When compressing:
- Keep all critical insights and evidence
- Remove examples that support the same point
- Tighten language and eliminate filler words
- Maintain structure and flow

When expanding:
- Add meaningful details and depth to existing arguments
- Include relevant examples, case studies, or scenarios
- Enhance analysis with more context
- Never invent data or unverifiable claims
- Use authoritative language and maintain professional tone

Always maintain PwC brand voice: collaborative, bold, and optimistic."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": action_prompt}
        ]
        
        logger.info(f"[CONTENT_RECREATION] Calling LLM to adjust content length")
        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            yield chunk
        
        logger.info(f"[CONTENT_RECREATION] Content adjustment completed")
