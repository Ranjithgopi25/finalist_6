from fastapi import APIRouter, Depends
import logging
from app.features.thought_leadership.services.edit_content import edit_content_agent

from app.features.thought_leadership.workflows import (
    draft_content,
    conduct_research,
    refine_content,
    format_translator,
    podcast,
    draft_article,
    research_materials,
    update_section
)
logger = logging.getLogger(__name__)
from app.services.auth_service import validate_jwt_token

def get_router() -> APIRouter:
    """Create and configure Thought Leadership router with all workflow sub-routers"""
    router = APIRouter(prefix="/tl", tags=["Thought Leadership"], dependencies=[Depends(validate_jwt_token)])
    router.include_router(draft_content.router, prefix="/draft-content", tags=["TL - Draft Content"])
    router.include_router(conduct_research.router, prefix="/conduct-research", tags=["TL - Conduct Research"])
    router.include_router(edit_content_agent.router, prefix="/edit-content", tags=["TL - Edit Content"])
    router.include_router(refine_content.router, prefix="/refine-content", tags=["TL - Refine Content"])
    router.include_router(format_translator.router, prefix="/format-translator", tags=["TL - Format Translator"])
    router.include_router(podcast.router, prefix="/generate-podcast", tags=["TL - Podcast"])
    router.include_router(research_materials.router, prefix="/research-with-materials", tags=["TL - Research Materials"])
    router.include_router(update_section.router, prefix="/update-section", tags=["TL - Canvas Update Section"])
    logger.info(f"adding all routes..................")
    return router
