from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Flowable
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER
import docx
from docx import Document
from docx.shared import Pt as DocxPt, Inches as DocxInches, RGBColor as DocxRGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from pypdf import PdfReader, PdfWriter
import io
import logging
import os
import re
import zipfile
import tempfile
from typing import List, Dict, Optional
from xml.etree import ElementTree as ET

logger = logging.getLogger(__name__)

# Path to PwC templates
PWC_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),"app","features","thought_leadership","template", "pwc_doc_template_2025.docx")
PWC_PDF_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),"app","features","thought_leadership","template", "pwc_pdf_template_2025.pdf")

def sanitize_text_for_word(text: str) -> str:
    """
    Sanitize text for Word export by ensuring all Unicode characters are properly encoded.
    This fixes encoding issues with special characters like em dashes, smart quotes, etc.
    """
    if not isinstance(text, str):
        text = str(text)
    
    # Ensure the text is valid Unicode
    try:
        # Normalize unicode (NFKC normalization handles most compatibility issues)
        text = text.encode('utf-8', errors='replace').decode('utf-8', errors='replace')
    except Exception as e:
        logger.warning(f"Error sanitizing text: {e}, using as-is")
    
    return text


def _fix_docx_encoding(buffer_bytes: bytes) -> bytes:
    """
    Fix DOCX encoding issues by re-serializing XML with proper UTF-8 encoding.
    This ensures all Unicode characters are properly handled in the Word document.
    """
    try:
        # Work with the bytes directly without temp file to avoid locking issues
        import io as io_module
        
        # Read the DOCX (which is a ZIP) directly from bytes
        try:
            input_zip = io_module.BytesIO(buffer_bytes)
            file_contents = {}
            
            with zipfile.ZipFile(input_zip, 'r') as zip_read:
                # Extract all files
                for name in zip_read.namelist():
                    try:
                        file_contents[name] = zip_read.read(name)
                    except Exception as e:
                        logger.warning(f"Could not read {name} from ZIP: {e}")
                        continue
            
            # Re-create the DOCX with proper UTF-8 encoding
            output_buffer = io_module.BytesIO()
            with zipfile.ZipFile(output_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_write:
                for name, content in file_contents.items():
                    # For XML files, ensure proper encoding
                    if name.endswith('.xml'):
                        try:
                            # Try to parse and re-serialize to ensure UTF-8
                            tree = ET.fromstring(content)
                            # Convert back to string with UTF-8 encoding
                            xml_str = ET.tostring(tree, encoding='unicode')
                            # Prepend XML declaration with UTF-8 encoding if not present
                            if not xml_str.startswith('<?xml'):
                                xml_str = '<?xml version="1.0" encoding="UTF-8"?>' + xml_str
                            content = xml_str.encode('utf-8')
                        except ET.ParseError as e:
                            logger.warning(f"Could not parse XML {name}: {e}, keeping original bytes")
                        except Exception as e:
                            logger.warning(f"Could not re-encode {name}: {e}, keeping original")
                    
                    try:
                        zip_write.writestr(name, content)
                    except Exception as e:
                        logger.warning(f"Could not write {name} to ZIP: {e}")
                        continue
            
            result = output_buffer.getvalue()
            logger.info(f"[_fix_docx_encoding] Successfully re-encoded DOCX with UTF-8, size: {len(result)} bytes")
            return result
        
        except Exception as e:
            logger.warning(f"[_fix_docx_encoding] Error during ZIP processing: {e}, returning original")
            return buffer_bytes
    
    except Exception as e:
        logger.warning(f"[_fix_docx_encoding] Failed to fix DOCX encoding: {e}, returning original")
        return buffer_bytes

def extract_subtitle_from_content(content: str) -> tuple[str, str]:
    """
    Extract subtitle from the first line of content.
    Returns (subtitle, remaining_content)
    
    The first non-empty line (after any markdown heading markers) becomes the subtitle,
    and the rest becomes the content.
    """
    lines = content.strip().split('\n')
    
    if not lines:
        return "", content
    
    # Get first non-empty line
    first_line = ""
    remaining_lines = []
    found_first = False
    
    for line in lines:
        stripped = line.strip()
        if not found_first and stripped:
            # Remove markdown heading markers from first line if present
            first_line = re.sub(r'^#+\s*', '', stripped)
            # Remove bold markers (both paired and stray **)
            first_line = re.sub(r'\*\*(.+?)\*\*', r'\1', first_line)
            # Remove any remaining stray ** characters
            first_line = first_line.replace('**', '')
            found_first = True
        elif found_first:
            remaining_lines.append(line)
    
    # Reconstruct remaining content
    remaining_content = '\n'.join(remaining_lines).strip()
    
    return first_line, remaining_content

def export_to_pdf(content: str, title: str = "Document") -> bytes:
    """Export content to PDF format"""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    
    story = []
    
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor='#D04A02',
        spaceAfter=30,
        alignment=TA_LEFT
    )
    
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['BodyText'],
        fontSize=11,
        leading=14,
        alignment=TA_JUSTIFY,
        spaceAfter=12
    )
    heading1_style = ParagraphStyle(
    'Heading1Bold',
    parent=styles['Heading1'],
    fontSize=16,
    leading=18,
    spaceAfter=12,
    alignment=TA_LEFT,
    textColor='black',
    fontName='Helvetica-Bold'
    )

    heading2_style = ParagraphStyle(
        'Heading2Bold',
        parent=styles['Heading2'],
        fontSize=14,
        leading=16,
        spaceAfter=10,
        alignment=TA_LEFT,
        textColor='black',
        fontName='Helvetica-Bold'
    )

    story.append(Paragraph(title, title_style))
    story.append(Spacer(1, 0.2 * inch))
    
    paragraphs = content.split('\n\n')
    for para in paragraphs:
        p = para.strip()
        if not p:
            continue
        bold_heading_match = re.match(r'^\*\*(.+?)\*\*$', p)
        if bold_heading_match:
            text = bold_heading_match.group(1).strip()
            story.append(Paragraph(f"<b>{text}</b>", heading1_style))
            continue
        
        # Check for bullet lists
        if _is_bullet_list_block(p):
            bullet_items = _parse_bullet_items(p)
            for item in bullet_items:
                # Display as indented text without any bullet prefix
                # This prevents ReportLab from auto-converting dashes to bullets
                # Add indentation using non-breaking spaces instead
                indented_text = f"\u00A0\u00A0\u00A0\u00A0{_format_content_for_pdf(item)}"
                story.append(Paragraph(indented_text, body_style))
            continue
        
        if p.startswith("## "):
            text = p.replace("##", "").strip()
            story.append(Paragraph(text, heading2_style))
        elif p.startswith("# "):
            text = p.replace("#", "").strip()
            story.append(Paragraph(text, heading1_style))
        else:
            # Intelligently split long paragraphs into smaller chunks
            sentence_count = len(re.findall(r'[.!?]', p))
            if sentence_count > 3:
                # This is a long paragraph, split it into smaller chunks (2-3 sentences each)
                split_paragraphs = _split_paragraph_into_sentences(p, target_sentences=3)
                for split_para in split_paragraphs:
                    if split_para:
                        p_html = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', split_para)
                        p_html = re.sub(r'(https?://\S+)',
                            r'<a href="\1" color="blue">\1</a>',
                            p_html
                        )
                        story.append(Paragraph(p_html, body_style))
            else:
                # Keep short paragraphs as is
                p_html = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', p)
                p_html = re.sub(r'(https?://\S+)',
                    r'<a href="\1" color="blue">\1</a>',
                    p_html
                )
                story.append(Paragraph(p_html, body_style))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def export_to_pdf_with_pwc_template(content: str, title: str = "Document", subtitle: str = "") -> bytes:
    """
    Export content to PDF format with PWC branded cover page.
    
    VALIDATED with test_branded_pdf.py - This function properly creates:
    1. A branded cover page by overlaying title/subtitle on PWC template
    2. Formatted content pages
    3. Final PDF: Cover (with logo) + Content Pages
    
    Args:
        content: The main content to export (starts from page 2)
        title: Document title (displays on cover page with logo)
        subtitle: Optional subtitle (displays on cover page)
    
    Returns:
        Bytes of the final PDF document with cover + content
    """
    try:
        from reportlab.pdfgen import canvas
        
        logger.info("Creating PWC branded PDF with title, subtitle, and content")
        
        # Check if template exists
        if not os.path.exists(PWC_PDF_TEMPLATE_PATH):
            logger.warning(f"PwC PDF template not found at {PWC_PDF_TEMPLATE_PATH}")
            return _generate_pdf_with_title_subtitle(content, title, subtitle)
        
        # ===== STEP 1: Create branded cover page =====
        logger.info("Step 1: Creating branded cover page")
        
        template_reader = PdfReader(PWC_PDF_TEMPLATE_PATH)
        template_page = template_reader.pages[0]
        
        page_width = float(template_page.mediabox.width)
        page_height = float(template_page.mediabox.height)
        
        logger.info(f"Template page size: {page_width:.1f} x {page_height:.1f} points")
        
        # Create overlay with text
        overlay_buffer = io.BytesIO()
        c = canvas.Canvas(overlay_buffer, pagesize=(page_width, page_height))
        
        # Add title
        title_font_size = 32
        if len(title) > 80:
            title_font_size = 20
        elif len(title) > 60:
            title_font_size = 22
        elif len(title) > 40:
            title_font_size = 26
        
        c.setFont("Helvetica-Bold", title_font_size)
        c.setFillColor('#000000')  # Black color
        title_y = page_height * 0.72
        
        # Handle multi-line titles with better word wrapping
        # Maximum width for title (leaving margins on left and right)
        max_title_width = page_width * 0.70  # 70% of page width with margins
        
        # Better character width estimation - more conservative to avoid cutoff
        # Estimate pixels needed per character based on font size
        # At 20pt Helvetica: ~10 pixels per character average
        char_width_at_font = (title_font_size / 20.0) * 10
        max_chars_per_line = int(max_title_width / char_width_at_font)
        
        # Ensure reasonable minimum and maximum
        max_chars_per_line = max(20, min(max_chars_per_line, 50))
        
        words = title.split()
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            # Use calculated character limit
            if len(test_line) > max_chars_per_line:
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
            else:
                current_line.append(word)
        
        if current_line:
            lines.append(' '.join(current_line))
        
        # Draw multi-line title
        if len(lines) > 1:
            line_height = title_font_size + 6
            # Center vertically: start higher if multiple lines
            start_y = title_y + (len(lines) - 1) * line_height / 2
            for i, line in enumerate(lines):
                c.drawCentredString(page_width / 2, start_y - (i * line_height), line)
            last_title_y = start_y - (len(lines) * line_height)
        else:
            c.drawCentredString(page_width / 2, title_y, title)
            last_title_y = title_y
        
        logger.info(f"Title added to overlay: {title} ({len(lines)} lines)")
        
        # Add subtitle if provided
        if subtitle:
            # Clean up markdown asterisks from subtitle
            subtitle_clean = subtitle.replace('**', '')
            
            c.setFont("Helvetica-Bold", 14)  # Bold font
            c.setFillColor('#000000')  # Black color
            subtitle_y = last_title_y - 70
            
            # Wrap subtitle text to fit within page width
            # Use a more conservative character limit for subtitle
            # Page width is typically 612 points (8.5 inches) for letter size
            # Helvetica 14pt: approximately 7-8 pixels per character
            max_subtitle_width = page_width * 0.75  # 75% of page width with margins
            subtitle_char_width = 8  # pixels per character at 14pt
            max_chars_per_line = int(max_subtitle_width / subtitle_char_width)
            
            words = subtitle_clean.split()
            lines = []
            current_line = []
            
            for word in words:
                test_line = ' '.join(current_line + [word])
                # Use more conservative line breaking - shorter lines for better visibility
                if len(test_line) > min(50, max_chars_per_line):
                    if current_line:
                        lines.append(' '.join(current_line))
                    current_line = [word]
                else:
                    current_line.append(word)
            
            if current_line:
                lines.append(' '.join(current_line))
            
            # Draw multi-line subtitle with proper centering
            line_height = 22
            # If multiple lines, center vertically
            if len(lines) > 1:
                start_y = subtitle_y + (len(lines) - 1) * line_height / 2
            else:
                start_y = subtitle_y
            
            for i, line in enumerate(lines):
                c.drawCentredString(page_width / 2, start_y - (i * line_height), line)
            
            logger.info(f"Subtitle added to overlay: {subtitle} ({len(lines)} lines)")
        
        c.save()
        overlay_buffer.seek(0)
        
        # Merge overlay with template
        overlay_reader = PdfReader(overlay_buffer)
        overlay_page = overlay_reader.pages[0]
        
        template_page.merge_page(overlay_page)
        logger.info("Overlay merged onto template cover page")
        
        # ===== STEP 2: Create content pages =====
        logger.info("Step 2: Creating formatted content pages")
        
        # First, extract all headings for Table of Contents
        headings = []
        blocks = content.split('\n\n')
        for block in blocks:
            if not block.strip():
                continue
            block = block.strip()
            
            # Check for various heading formats
            standalone_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*$', block)
            if standalone_bold_match:
                headings.append(standalone_bold_match.group(1).strip())
                continue
            
            first_line_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*\n', block)
            if first_line_bold_match:
                headings.append(first_line_bold_match.group(1).strip())
                continue
            
            # Markdown headings
            if block.startswith('#'):
                text = re.sub(r'^#+\s*', '', block.split('\n')[0]).strip()
                headings.append(text)
        
        logger.info(f"Extracted {len(headings)} headings for Table of Contents")
        
        content_buffer = io.BytesIO()
        doc = SimpleDocTemplate(content_buffer, pagesize=letter, topMargin=1*inch, bottomMargin=1*inch)
        styles = getSampleStyleSheet()
        
        # Define custom styles
        body_style = ParagraphStyle(
            'PWCBody',
            parent=styles['BodyText'],
            fontSize=11,
            leading=15,
            alignment=TA_JUSTIFY,
            spaceAfter=12,
            fontName='Helvetica'
        )
        
        heading_style = ParagraphStyle(
            'PWCHeading',
            parent=styles['Heading2'],
            fontSize=14,
            textColor='#D04A02',
            spaceAfter=10,
            spaceBefore=10,
            fontName='Helvetica-Bold'
        )
        
        # Citation style with left alignment (no justify to avoid extra spaces)
        citation_style = ParagraphStyle(
            'PWCCitation',
            parent=styles['BodyText'],
            fontSize=11,
            leading=15,
            alignment=TA_LEFT,
            spaceAfter=12,
            fontName='Helvetica'
        )
        
        story = []
        
        # Parse and add content with formatting
        blocks = content.split('\n\n')
        for block in blocks:
            if not block.strip():
                continue
            
            block = block.strip()
            
            # Check for headings (bold text on its own line or markdown style)
            standalone_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*$', block)
            if standalone_bold_match:
                heading_text = standalone_bold_match.group(1).strip()
                story.append(Paragraph(heading_text, heading_style))
                continue
            
            # Check for bold text at start of paragraph
            first_line_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*\n', block)
            if first_line_bold_match:
                heading_text = first_line_bold_match.group(1).strip()
                remaining_content = block[first_line_bold_match.end():].strip()
                story.append(Paragraph(heading_text, heading_style))
                if remaining_content:
                    # Check if remaining content is a bullet list
                    if _is_bullet_list_block(remaining_content):
                        bullet_items = _parse_bullet_items(remaining_content)
                        for item in bullet_items:
                            # Display as indented text without any bullet prefix
                            # This prevents ReportLab from auto-converting dashes to bullets
                            indented_text = f"\u00A0\u00A0\u00A0\u00A0{_format_content_for_pdf(item)}"
                            bullet_para = Paragraph(indented_text, body_style)
                            story.append(bullet_para)
                    else:
                        para = Paragraph(_format_content_for_pdf(remaining_content), body_style)
                        story.append(para)
                continue
            
            # Check for markdown headings
            if block.startswith('####'):
                text = block.replace('####', '').strip()
                story.append(Paragraph(text, heading_style))
                continue
            elif block.startswith('###'):
                text = block.replace('###', '').strip()
                story.append(Paragraph(text, heading_style))
                continue
            elif block.startswith('##'):
                text = block.replace('##', '').strip()
                story.append(Paragraph(text, heading_style))
                continue
            elif block.startswith('#'):
                text = block.replace('#', '').strip()
                story.append(Paragraph(text, heading_style))
                continue
            
            # Check if block is a bullet list
            if _is_bullet_list_block(block):
                bullet_items = _parse_bullet_items(block)
                for item in bullet_items:
                    # Display as indented text without any bullet prefix
                    # This prevents ReportLab from auto-converting dashes to bullets
                    indented_text = f"\u00A0\u00A0\u00A0\u00A0{_format_content_for_pdf(item)}"
                    bullet_para = Paragraph(indented_text, body_style)
                    story.append(bullet_para)
                continue
            
            # Check if block contains multiple lines with citation patterns
            # Citations typically look like: [1] text or 1. text
            lines = block.split('\n')
            if len(lines) > 1:
                # Check if this looks like a citation/reference block
                citation_pattern = r'^\s*(\[\d+\]|\d+\.)\s+'
                citation_count = sum(1 for line in lines if re.match(citation_pattern, line.strip()))
                
                # If at least 2 lines match citation pattern, treat as citation block
                if citation_count >= 2:
                    # Process each line separately with left alignment (no justify)
                    for line in lines:
                        line_stripped = line.strip()
                        if line_stripped:
                            para = Paragraph(_format_content_for_pdf(line_stripped), citation_style)
                            story.append(para)
                    continue
            
            # Regular paragraph - intelligently split long paragraphs into smaller chunks
            sentence_count = len(re.findall(r'[.!?]', block))
            if sentence_count > 3:
                # This is a long paragraph, split it into smaller chunks (2-3 sentences each)
                split_paragraphs = _split_paragraph_into_sentences(block, target_sentences=3)
                for split_para in split_paragraphs:
                    if split_para:
                        para = Paragraph(_format_content_for_pdf(split_para), body_style)
                        story.append(para)
            else:
                # Keep short paragraphs as is
                para = Paragraph(_format_content_for_pdf(block), body_style)
                story.append(para)
        
        # Build the content PDF
        doc.build(story)
        content_buffer.seek(0)
        
        # ===== STEP 2.5: Create Table of Contents pages (multi-page support) =====
        logger.info("Step 2.5: Creating Table of Contents pages (multi-page)")
        toc_buffer = io.BytesIO()
        toc_doc = SimpleDocTemplate(toc_buffer, pagesize=(page_width, page_height), topMargin=1*inch, bottomMargin=1*inch)
        toc_styles = getSampleStyleSheet()
        toc_title_style = ParagraphStyle(
            'TOCTitle',
            parent=toc_styles['Heading1'],
            fontSize=24,
            textColor='#000000',
            spaceAfter=24,
            alignment=TA_LEFT,
            fontName='Helvetica-Bold'
        )
        toc_heading_style = ParagraphStyle(
            'TOCHeading',
            parent=toc_styles['BodyText'],
            fontSize=11,
            textColor='#000000',
            spaceAfter=12,
            alignment=TA_LEFT,
            fontName='Helvetica',
            leading=16,
            rightIndent=20
        )
        toc_story = []
        toc_story.append(Paragraph("Contents", toc_title_style))
        toc_story.append(Spacer(1, 0.2 * inch))
        for index, heading in enumerate(headings, start=1):
            # Add serial number before heading (ReportLab will handle text wrapping automatically)
            toc_story.append(Paragraph(f"{index}. {heading}", toc_heading_style))
        toc_doc.build(toc_story)
        toc_buffer.seek(0)
        toc_reader = PdfReader(toc_buffer)
        toc_pages = [toc_reader.pages[i] for i in range(len(toc_reader.pages))]
        # ===== STEP 3: Merge cover + ToC + content =====
        logger.info("Step 3: Merging cover page, ToC, and content pages")
        
        content_reader = PdfReader(content_buffer)
        
        writer = PdfWriter()
        
        # Add the branded cover page (Page 1)
        writer.add_page(template_page)
        logger.info("Added branded cover page with PWC logo, title, and subtitle")
        
        # Add the Table of Contents pages (Page 2+)
        for idx, toc_page in enumerate(toc_pages):
            writer.add_page(toc_page)
            logger.info(f"Added Table of Contents page {idx+1}")
        
        # Add all content pages (Page 3+)
        for page_num in range(len(content_reader.pages)):
            logger.info(f"Adding content page {page_num + 1}")
            writer.add_page(content_reader.pages[page_num])
        
        # Write final PDF
        output_buffer = io.BytesIO()
        writer.write(output_buffer)
        output_buffer.seek(0)
        
        result_bytes = output_buffer.getvalue()
        logger.info(f"PDF export complete: {len(writer.pages)} pages, {len(result_bytes)} bytes")
        
        return result_bytes
            
    except Exception as e:
        logger.error(f"Error exporting to PDF with PwC template: {e}", exc_info=True)
        # Fallback to basic PDF
        return _generate_pdf_with_title_subtitle(content, title, subtitle)


def _generate_pdf_with_title_subtitle(content: str, title: str, subtitle: str = "") -> bytes:
    """
    Generate a professional PDF with title, subtitle, and content.
    Used as fallback when PWC template is unavailable.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=28,
        textColor='#D04A02',
        spaceAfter=20,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    subtitle_style = ParagraphStyle(
        'CustomSubtitle',
        parent=styles['Heading2'],
        fontSize=14,
        textColor='#666666',
        spaceAfter=40,
        alignment=TA_CENTER,
        fontName='Helvetica'
    )
    
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['BodyText'],
        fontSize=11,
        leading=14,
        alignment=TA_JUSTIFY,
        spaceAfter=12
    )
    
    story = []
    
    # Add title
    story.append(Paragraph(title, title_style))
    
    # Add subtitle
    if subtitle:
        story.append(Paragraph(subtitle, subtitle_style))
    else:
        story.append(Spacer(1, 0.3 * inch))
    
    # Add content with intelligent paragraph splitting
    paragraphs = content.split('\n\n')
    for para in paragraphs:
        if para.strip():
            # Check if this is a long paragraph that should be split
            sentence_count = len(re.findall(r'[.!?]', para.strip()))
            
            if sentence_count > 3:
                # This is a long paragraph, split it into smaller chunks
                split_paragraphs = _split_paragraph_into_sentences(para.strip(), target_sentences=3)
                for split_para in split_paragraphs:
                    if split_para:
                        story.append(Paragraph(split_para, body_style))
            else:
                # Keep short paragraphs as is
                story.append(Paragraph(para.strip(), body_style))
    
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def _format_content_for_pdf(text: str) -> str:
    """
    Format content for PDF by converting markdown-style formatting to HTML-like tags.
    Reportlab supports a subset of HTML/XML tags for styling.
    
    Converts:
    - **bold** to <b>bold</b>
    - *italic* to <i>italic</i>
    - Normalizes all Unicode dash variants to standard hyphen for reliable PDF rendering
    """
    # Normalize all Unicode dash/hyphen variants to standard ASCII hyphen-minus (-)
    # This prevents ReportLab rendering issues with special Unicode characters
    dash_variants = [
        '\u2010',  # Hyphen
        '\u2011',  # Non-breaking hyphen
        '\u2012',  # Figure dash
        '\u2013',  # En dash (–)
        '\u2014',  # Em dash (—)
        '\u2015',  # Horizontal bar
        '\u2212',  # Minus sign
        '\u058A',  # Armenian hyphen
        '\u05BE',  # Hebrew maqaf
        '\u1400',  # Canadian syllabics hyphen
        '\u1806',  # Mongolian todo soft hyphen
        '\u2E17',  # Double oblique hyphen
        '\u30A0',  # Katakana-hiragana double hyphen
        '\uFE58',  # Small em dash
        '\uFE63',  # Small hyphen-minus
        '\uFF0D',  # Fullwidth hyphen-minus
    ]
    
    for dash in dash_variants:
        text = text.replace(dash, '-')
    
    # Also handle special quotation marks and other problematic characters
    text = text.replace('\u201C', '"')  # Left double quotation mark
    text = text.replace('\u201D', '"')  # Right double quotation mark
    text = text.replace('\u2018', "'")  # Left single quotation mark
    text = text.replace('\u2019', "'")  # Right single quotation mark
    text = text.replace('\u2026', '...')  # Ellipsis
    
    # Convert **bold** to <b>bold</b>
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    
    # Convert *italic* to <i>italic</i> (but not if it's part of **bold** or at line start for bullets)
    # Use negative lookbehind/lookahead to avoid double-processing
    text = re.sub(r'(?<!\*)\*([^\*]+?)\*(?!\*)', r'<i>\1</i>', text)
    
    return text


def _is_bullet_list_block(block: str) -> bool:
    """Check if a block contains bullet points"""
    lines = block.split('\n')
    bullet_count = 0
    for line in lines:
        stripped = line.strip()
        if stripped and (stripped.startswith('- ') or stripped.startswith('• ') or stripped.startswith('* ')):
            bullet_count += 1
    return bullet_count > 0


def _parse_bullet_items(block: str) -> list:
    """Parse bullet items from a block and return list of bullet texts"""
    lines = block.split('\n')
    items = []
    for line in lines:
        stripped = line.strip()
        if stripped and (stripped.startswith('- ') or stripped.startswith('• ') or stripped.startswith('* ')):
            # Remove bullet marker and leading/trailing whitespace
            bullet_text = re.sub(r'^[-•\*]\s+', '', stripped)
            items.append(bullet_text)
    return items


def _split_paragraph_into_sentences(paragraph: str, target_sentences: int = 3) -> List[str]:
    """
    Split a long paragraph into smaller paragraphs by sentence boundaries.
    
    This ensures that even if content doesn't have explicit paragraph breaks (\n\n),
    long blocks of text are divided into readable chunks of 2-3 sentences each.
    
    Args:
        paragraph: The paragraph text to split
        target_sentences: Target number of sentences per paragraph chunk (default: 3)
    
    Returns:
        List of paragraph strings, each containing roughly target_sentences sentences
    """
    if not paragraph or not paragraph.strip():
        return []
    
    # Split by sentence boundaries (period, question mark, exclamation mark followed by space)
    # This regex splits on . ? ! followed by a space and capital letter, preserving the punctuation
    sentence_pattern = r'(?<=[.!?])\s+(?=[A-Z])'
    sentences = re.split(sentence_pattern, paragraph.strip())
    
    if len(sentences) <= target_sentences:
        # If paragraph has 3 or fewer sentences, keep it as is
        return [paragraph.strip()]
    
    # Group sentences into chunks
    paragraphs = []
    current_chunk = []
    
    for sentence in sentences:
        current_chunk.append(sentence)
        
        # When we have enough sentences, create a new paragraph
        if len(current_chunk) >= target_sentences:
            paragraphs.append(' '.join(current_chunk).strip())
            current_chunk = []
    
    # Add remaining sentences
    if current_chunk:
        paragraphs.append(' '.join(current_chunk).strip())
    
    return paragraphs

def add_hyperlink(paragraph, url, text=None): #merge conflict resolved
    if not text:
        text = url

    part = paragraph.part
    r_id = part.relate_to(url, docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, is_external=True)

    hyperlink = OxmlElement('w:hyperlink')
    hyperlink.set(qn('r:id'), r_id)

    run = OxmlElement('w:r')
    rPr = OxmlElement('w:rPr')

    # Style (blue + underline)
    u = OxmlElement('w:u')
    u.set(qn('w:val'), 'single')
    rPr.append(u)

    color = OxmlElement('w:color')
    color.set(qn('w:val'), '0000FF')
    rPr.append(color)

    run.append(rPr)
    t = OxmlElement('w:t')
    t.text = text
    run.append(t)

    hyperlink.append(run)
    paragraph._p.append(hyperlink)

def export_to_word(content: str, title: str = "Document") -> bytes:
    """Export content to Word DOCX format using PwC template"""
    try:
        # Load PwC template
        if os.path.exists(PWC_TEMPLATE_PATH):
            doc = Document(PWC_TEMPLATE_PATH)
            logger.info(f"Loaded PwC template from: {PWC_TEMPLATE_PATH}")
        else:
            logger.warning(f"PwC template not found at {PWC_TEMPLATE_PATH}, using default formatting")
            doc = Document()
    except Exception as e:
        logger.warning(f"Failed to load PwC template: {e}, using default formatting")
        doc = Document()
    
    # Check if template has proper structure (Title, Subtitle, page breaks)
    has_template_structure = (
        len(doc.paragraphs) > 2 and 
        doc.paragraphs[0].style.name == 'Title' and
        doc.paragraphs[1].style.name == 'Subtitle'
    )
    
    if has_template_structure:
        # Use template structure: update title, clear subtitle, remove page break paragraphs
        # Update title (paragraph 0)
        _set_paragraph_text_with_breaks(doc.paragraphs[0], title)
        
        # Clear subtitle (paragraph 1) - will be empty for basic export
        _set_paragraph_text_with_breaks(doc.paragraphs[1], '')
        
        # Remove ALL template content after title and subtitle (including old TOC and page breaks)
        paragraphs_to_remove = list(doc.paragraphs[2:])
        for para in paragraphs_to_remove:
            p = para._element
            p.getparent().remove(p)

        # Add page break after subtitle
        _ensure_page_break_after_paragraph(doc.paragraphs[1])
        
        # Extract headings from content before adding it
        headings = _extract_headings_from_content(content)
        
        # Add Table of Contents on page 2
        if headings:
            _add_table_of_contents(doc, headings)
        
        # Add a page break before the generated content so it starts after the TOC page
        page_break_para = doc.add_paragraph()
        run = page_break_para.add_run()
        run.add_break(WD_BREAK.PAGE)
        
        # Add content after the page break
        _add_formatted_content(doc, content)
    else:
        # No template structure, clear everything and build from scratch
        for para in doc.paragraphs[:]:
            p = para._element
            p.getparent().remove(p)
        
        # Add title using Title style
        title_para = doc.add_paragraph(title, style='Title')
        
        # Add a blank line after title
        doc.add_paragraph()
        
        # Parse and add content with proper formatting
        _add_formatted_content(doc, content)
    
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    docx_bytes = buffer.getvalue()
    
    # Apply encoding fix to ensure all Unicode characters are properly handled
    docx_bytes = _fix_docx_encoding(docx_bytes)
    
    return docx_bytes

def _add_bookmark_to_paragraph(para, bookmark_name: str):
    """Add a bookmark to a paragraph"""
    # Create bookmark start
    bookmark_start = OxmlElement('w:bookmarkStart')
    bookmark_start.set(qn('w:id'), '0')
    bookmark_start.set(qn('w:name'), bookmark_name)
    
    # Create bookmark end
    bookmark_end = OxmlElement('w:bookmarkEnd')
    bookmark_end.set(qn('w:id'), '0')
    
    # Add to paragraph
    para._element.insert(0, bookmark_start)
    para._element.append(bookmark_end)

def export_to_word_pwc_standalone(
    content: str,
    title: str,
    subtitle: str | None = None,
    content_type: str | None = None,
    references: list[dict] | None = None
) -> bytes:
    logger.error("🚨 export_to_word_pwc_standalone() IS BEING CALLED")
    doc = Document(PWC_TEMPLATE_PATH) if os.path.exists(PWC_TEMPLATE_PATH) else Document()
    toc_headings: list[str] = []
    _set_paragraph_text_with_breaks(doc.paragraphs[0], sanitize_text_for_word(title))
    _set_paragraph_text_with_breaks(doc.paragraphs[1], sanitize_text_for_word(subtitle or ""))
    for para in list(doc.paragraphs[2:]):
        para._element.getparent().remove(para._element)
    for block in content.split("\n\n"):
        block = block.strip()
        if not block:
            continue
        m = re.match(r'^\*\*(.+?)\*\*$', block)
        if m:
            text = m.group(1).strip()
        elif block.startswith("# "):
            text = block[2:].strip()
        elif block.startswith("##"):
            continue  
        else:
            continue
        text = re.sub(r'^\d+(\.\d+)*\s*', '', text)
        toc_headings.append(sanitize_text_for_word(text))
        _set_paragraph_text_with_breaks(doc.paragraphs[0], toc_headings[0])

    _ensure_page_break_after_paragraph(doc.paragraphs[1])

    if toc_headings:
        doc.add_paragraph("Contents", style="Heading 1")
        doc.add_paragraph()

        for i, heading in enumerate(toc_headings, 1):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = DocxInches(0.5)
            run = p.add_run(sanitize_text_for_word(f"{i} {heading}")); run.font.underline = False
            run.font.size = DocxPt(11)

        doc.add_page_break()
    for block in content.split("\n\n"):
        block = block.strip()
        if re.fullmatch(r'[-•–—]+', block):
            continue
        if not block:
            continue
        if block.startswith("##"):
           text = block.replace("##", "").strip()
           p = doc.add_paragraph(style="Heading 2")
           _add_markdown_text_runs(p, text)
           continue
        if block.startswith("#") and not block.startswith("##"):
            text = block.replace("#", "").strip()
            p = doc.add_paragraph(style="Heading 1")
            _add_markdown_text_runs(p, text)
            continue
        m = re.match(r'^\*\*(.+?)\*\*$', block)
        if m:
            p = doc.add_paragraph(style="Heading 1")
            _add_markdown_text_runs(p, m.group(1))
            continue
        if block.startswith(("-", "•", "*")):
            for line in block.split("\n"):
                line = re.sub(r'^[•\-\*]\s*', '', line.strip())
                if line:
                    para = doc.add_paragraph(style="List Bullet")
                    _add_markdown_text_runs(para, line)
                    continue

        para = doc.add_paragraph(style="Body Text")
        _add_markdown_text_runs(para, block)
    if references:
        doc.add_page_break()
        doc.add_paragraph("References", style="Heading 2")

        for ref in references:
            para = _add_numbered_paragraph(
                doc,
                sanitize_text_for_word(ref.get("title", ""))
            )

            if ref.get("url"):
                add_hyperlink(para, ref["url"])

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return _fix_docx_encoding(buffer.getvalue())

def _add_markdown_text_runs(paragraph, text: str):
    """
    Adds text to a paragraph supporting:
    **bold**
    *italic*
    normal text
    """
    parts = []
    remaining = text

    # Pass 1: bold
    while remaining:
        bold_match = re.search(r'\*\*(.+?)\*\*', remaining)
        if bold_match:
            before = remaining[:bold_match.start()]
            if before:
                parts.append(('normal', before))
            parts.append(('bold', bold_match.group(1)))
            remaining = remaining[bold_match.end():]
        else:
            if remaining:
                parts.append(('normal', remaining))
            break

    # Pass 2: italic
    final_parts = []
    for part_type, part_text in parts:
        if part_type == 'bold':
            final_parts.append(('bold', part_text))
        else:
            remaining = part_text
            while remaining:
                italic_match = re.search(r'(?<!\*)\*([^\*]+?)\*(?!\*)', remaining)
                if italic_match:
                    before = remaining[:italic_match.start()]
                    if before:
                        final_parts.append(('normal', before))
                    final_parts.append(('italic', italic_match.group(1)))
                    remaining = remaining[italic_match.end():]
                else:
                    if remaining:
                        final_parts.append(('normal', remaining))
                    break

    # Pass 3: write runs
    for part_type, part_text in final_parts:
        if not part_text:
            continue
        run = paragraph.add_run(sanitize_text_for_word(part_text))
        if part_type == 'bold':
            run.bold = True
        elif part_type == 'italic':
            run.italic = True

def _add_numbered_paragraph(doc: Document, text: str):
    """
    Create a numbered paragraph with a BRAND-NEW numbering instance.
    Always starts from 1. Never interferes with other lists.
    """
    numbering_part = doc.part.numbering_part

    # Create a new abstract numbering definition
    abstract_num_id = numbering_part._next_abstract_num_id
    numbering_part._next_abstract_num_id += 1

    abstract_num = OxmlElement("w:abstractNum")
    abstract_num.set(qn("w:abstractNumId"), str(abstract_num_id))

    lvl = OxmlElement("w:lvl")
    lvl.set(qn("w:ilvl"), "0")

    start = OxmlElement("w:start")
    start.set(qn("w:val"), "1")

    lvl_restart = OxmlElement("w:lvlRestart")
    lvl_restart.set(qn("w:val"), "1") 
    num_fmt = OxmlElement("w:numFmt")
    num_fmt.set(qn("w:val"), "decimal")

    lvl_text = OxmlElement("w:lvlText")
    lvl_text.set(qn("w:val"), "%1.")

    lvl.extend([start, lvl_restart, num_fmt, lvl_text])
    abstract_num.append(lvl)
    numbering_part._numbering.append(abstract_num)

    # Create a new numbering instance
    num_id = numbering_part._next_num_id
    numbering_part._next_num_id += 1

    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))

    abstract_ref = OxmlElement("w:abstractNumId")
    abstract_ref.set(qn("w:val"), str(abstract_num_id))

    num.append(abstract_ref)
    numbering_part._numbering.append(num)

    # Create paragraph using this numbering
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()

    numPr = OxmlElement("w:numPr")
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    numId = OxmlElement("w:numId")
    numId.set(qn("w:val"), str(num_id))

    numPr.extend([ilvl, numId])
    pPr.append(numPr)

    p.add_run(text)
    return p

def _add_references_section(doc: Document, references: list[dict]):
    doc.add_page_break()
    doc.add_paragraph("References", style="Heading 2")

    for ref in references:
        para = _add_numbered_paragraph(doc, ref["title"])

        if ref.get("url"):
            add_hyperlink(para, ref["url"])

def _add_formatted_content(doc: Document, content: str, references: list[dict] | None = None):
    """Parse and add content to document with appropriate styles"""
    
    # Split content into blocks (paragraphs separated by blank lines)
    blocks = content.split('\n\n')

    for block in blocks:
        if not block.strip():
            continue
        
        # Check for headings (lines starting with # or **bold** markers)
        block = block.strip()
        
        # Check if the block is a standalone bold text (likely a heading)
        # Pattern: **Text** at the start of a line, possibly followed by newline or end of block
        standalone_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*$', block)
        if standalone_bold_match:
            # This is a standalone bold text, treat as Heading 2
            text = standalone_bold_match.group(1).strip()
            sanitized_text = sanitize_text_for_word(text)
            para = doc.add_paragraph(style='Heading 2')
            # para.add_run(text)
            run = para.add_run(sanitized_text)
            run.bold = True

            # Add bookmark for TOC page number reference
            bookmark_name = text.replace(" ", "_").replace("&", "and")
            _add_bookmark_to_paragraph(para, bookmark_name)
            continue
        
        # Check if the block starts with bold text on first line (likely a section header)
        # Pattern: **Text** followed by newline and more content
        first_line_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*\n', block)
        if first_line_bold_match:
            # Extract the bold heading and remaining content
            heading_text = first_line_bold_match.group(1).strip()
            sanitized_heading = sanitize_text_for_word(heading_text)
            remaining_content = block[first_line_bold_match.end():].strip()
            
            # Add heading
            para = doc.add_paragraph(style='Heading 2')
            # para.add_run(heading_text)
            run = para.add_run(sanitized_heading)
            run.bold = True
            # Add bookmark for TOC page number reference
            bookmark_name = heading_text.replace(" ", "_").replace("&", "and")
            _add_bookmark_to_paragraph(para, bookmark_name)
            
            # Process remaining content recursively
            if remaining_content:
                _add_formatted_content(doc, remaining_content)
            continue
        
        # Detect markdown-style headings
        if block.startswith('####'):
            # Heading 4
            text = block.replace('####', '').strip()
            para = doc.add_paragraph(style='Heading 4')
            _add_text_with_formatting(para, text)
        elif block.startswith('###'):
            # Heading 3
            text = block.replace('###', '').strip()
            para = doc.add_paragraph(style='Heading 3')
            _add_text_with_formatting(para, text)
        elif block.startswith('##'):
            # Heading 2
            text = block.replace('##', '').strip()
            sanitized_text = sanitize_text_for_word(text)
            para = doc.add_paragraph(style='Heading 2')
            run = para.add_run(sanitized_text)
            run.bold = True
            _add_text_with_formatting(para, text)
        elif block.startswith('#'):
            # Heading 1
            text = block.replace('#', '').strip()
            para = doc.add_paragraph(style='Heading 1')
            _add_text_with_formatting(para, text)
        
        # Detect bullet lists
        elif block.startswith('•') or block.startswith('- ') or block.startswith('* '):
            lines = block.split('\n')
            for line in lines:
                if line.strip():
                    # Remove bullet markers
                    text = re.sub(r'^[•\-\*]\s*', '', line.strip())
                    para = doc.add_paragraph(style='List Bullet')
                    _add_text_with_formatting(para, text)
        
        # Detect numbered lists
        elif re.match(r'^\d+\.', block):
            lines = block.split('\n')
            for line in lines:
                if line.strip():
                    # Remove number markers
                    text = re.sub(r'^\d+\.\s*', '', line.strip())
                    para = doc.add_paragraph(style='List Number')
                    _add_text_with_formatting(para, text)
        
        # Check if block contains multiple lines (multi-line paragraph)
        elif '\n' in block:
            # Check if it's a list within the block
            lines = block.split('\n')
            in_list = False
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                # Check for bullet points
                if line.startswith('•') or line.startswith('- ') or line.startswith('* '):
                    text = re.sub(r'^[•\-\*]\s*', '', line)
                    para = doc.add_paragraph(style='List Bullet')
                    _add_text_with_formatting(para, text)
                    in_list = True
                # Check for numbered items
                elif re.match(r'^\d+\.', line):
                    text = re.sub(r'^\d+\.\s*', '', line)
                    para = doc.add_paragraph(style='List Number')
                    _add_text_with_formatting(para, text)
                    in_list = True
                else:
                    # Regular paragraph continuation
                    if in_list:
                        para = doc.add_paragraph(style='List Continue')
                        _add_text_with_formatting(para, line)
                    else:
                        para = doc.add_paragraph(style='Body Text')
                        _add_text_with_formatting(para, line)
        
        # Regular paragraph
        else:
            # Intelligently split long paragraphs into smaller chunks
            sentence_count = len(re.findall(r'[.!?]', block))
            
            if sentence_count > 3:
                # This is a long paragraph, split it into smaller chunks (2-3 sentences each)
                split_paragraphs = _split_paragraph_into_sentences(block, target_sentences=3)
                for split_para in split_paragraphs:
                    if split_para:
                        para = doc.add_paragraph(style='Body Text')
                        urls = re.findall(r'(https?://\S+)', split_para)
                        if urls:
                            para.clear()
                            for url in urls:
                                add_hyperlink(para, url)
                            continue
                        _add_text_with_formatting(para, split_para)
            else:
                # Keep short paragraphs as is
                para = doc.add_paragraph(style='Body Text')
                urls = re.findall(r'(https?://\S+)', block)
                if urls:
                    para.clear()
                    for url in urls:
                        add_hyperlink(para, url)
                    continue 
                _add_text_with_formatting(para, block)

    if references:
        _add_references_section(doc, references)

def _set_paragraph_text_with_breaks(para, text):
    """
    Safely set paragraph text with proper line breaks.
    Clears existing runs and adds new text with line breaks where \n appears.
    """
    # Sanitize text first
    text = sanitize_text_for_word(text)
    
    # Clear existing runs
    for run in para.runs[:]:
        run._element.getparent().remove(run._element)
    
    # Split text by newlines and add with proper breaks
    lines = text.split('\n')
    for i, line in enumerate(lines):
        sanitized_line = sanitize_text_for_word(line)
        run = para.add_run(sanitized_line)
        # Add soft line break after each line except the last
        if i < len(lines) - 1:
            run.add_break()

def _ensure_page_break_after_paragraph(para):
    """Add a page break after the given paragraph if one is not already present."""
    # If the last run already ends with a page break, do nothing
    if para.runs:
        last_run = para.runs[-1]
        if getattr(last_run, "break_type", None) == WD_BREAK.PAGE:
            return
    run = para.add_run()
    run.add_break(WD_BREAK.PAGE)

def _extract_headings_from_content(content: str) -> List[str]:
    """
    Extract all headings from content (both markdown # style and **bold** style).
    Returns a list of heading texts in order.
    
    Note: Includes all bold text items and section headers in the table of contents.
    """
    headings = []
    blocks = content.split('\n\n')
    
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        
        # Check for standalone bold text (heading)
        standalone_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*$', block)
        if standalone_bold_match:
            headings.append(standalone_bold_match.group(1).strip())
            continue
        
        # Check for bold text at start of paragraph
        first_line_bold_match = re.match(r'^\*\*([^\*]+?)\*\*\s*\n', block)
        if first_line_bold_match:
            headings.append(first_line_bold_match.group(1).strip())
            continue
        
        # Check for markdown headings
        if block.startswith('####'):
            headings.append(block.replace('####', '').strip())
        elif block.startswith('###'):
            headings.append(block.replace('###', '').strip())
        elif block.startswith('##'):
            headings.append(block.replace('##', '').strip())
        elif block.startswith('#'):
            headings.append(block.replace('#', '').strip())
    
    return headings

def _add_table_of_contents(doc: Document, headings: List[str]):
    """
    Add a custom table of contents with the provided headings and page numbers.
    Uses Word bookmarks and page number fields to automatically track page numbers.
    Includes serial numbers (1, 2, 3, ...) before each heading.
    """
    # Add "Contents" heading
    toc_title = doc.add_paragraph("Contents", style='Heading 1')
    doc.add_paragraph()  # Blank line
    
    # Add each heading as a TOC entry with serial number and page number field
    for index, heading in enumerate(headings, start=1):
        # Create a paragraph for the TOC entry
        toc_entry = doc.add_paragraph()
        toc_entry.paragraph_format.left_indent = DocxInches(0.5)
        
        # Add the serial number and heading text
        run = toc_entry.add_run(f"{index}. {heading}")
        run.font.size = DocxPt(11)
        
        # Add page number field that will be populated by Word
        # This uses the PAGEREF field to reference the page where the heading appears
        page_run = toc_entry.add_run()
        page_run.font.size = DocxPt(11)
        
        # Create a page number field using Word's field syntax
        fldChar1 = OxmlElement('w:fldChar')
        fldChar1.set(qn('w:fldCharType'), 'begin')
        
        instrText = OxmlElement('w:instrText')
        instrText.set(qn('xml:space'), 'preserve')
        instrText.text = f'PAGEREF "{heading.replace(" ", "_")}" \\h'
        
        fldChar2 = OxmlElement('w:fldChar')
        fldChar2.set(qn('w:fldCharType'), 'end')
        
        # Add field elements to the run
        page_run._r.append(fldChar1)
        page_run._r.append(instrText)
        page_run._r.append(fldChar2)
        
        # Add a space before page number
        toc_entry.runs[1].text = ' ' + toc_entry.runs[1].text


def _add_text_with_formatting(para, text):
    """
    Add text to a paragraph with inline markdown formatting (bold, italic).
    Supports **bold** and *italic* markdown syntax.
    Handles nested cases by processing bold first, then italic within non-bold sections.
    """
    # First pass: Process **bold** text
    # Pattern matches ** followed by any content (non-greedy) then **
    parts = []
    remaining = text
    
    while remaining:
        bold_match = re.search(r'\*\*(.+?)\*\*', remaining)
        if bold_match:
            # Add text before bold
            before = remaining[:bold_match.start()]
            if before:
                parts.append(('normal', before))
            # Add bold text
            parts.append(('bold', bold_match.group(1)))
            remaining = remaining[bold_match.end():]
        else:
            # No more bold, add remaining text
            if remaining:
                parts.append(('normal', remaining))
            break
    
    # Second pass: Process *italic* in non-bold parts
    final_parts = []
    for part_type, part_text in parts:
        if part_type == 'bold':
            # Keep bold as-is
            final_parts.append(('bold', part_text))
        else:
            # Process italic in normal text
            remaining = part_text
            while remaining:
                italic_match = re.search(r'(?<!\*)\*([^\*]+?)\*(?!\*)', remaining)
                if italic_match:
                    # Add text before italic
                    before = remaining[:italic_match.start()]
                    if before:
                        final_parts.append(('normal', before))
                    # Add italic text
                    final_parts.append(('italic', italic_match.group(1)))
                    remaining = remaining[italic_match.end():]
                else:
                    # No more italic, add remaining text
                    if remaining:
                        final_parts.append(('normal', remaining))
                    break
    
    # Third pass: Add runs to paragraph with sanitized text
    for part_type, part_text in final_parts:
        if not part_text:
            continue
        # Sanitize text before adding to paragraph
        sanitized_text = sanitize_text_for_word(part_text)
        run = para.add_run(sanitized_text)
        if part_type == 'bold':
            run.bold = True
        elif part_type == 'italic':
            run.italic = True


def export_to_word_with_metadata(content: str, title: str, subtitle: Optional[str] = None, 
                                   content_type: Optional[str] = None) -> bytes:
    """
    Export content to Word DOCX format using PwC template with metadata
    
    Args:
        content: The main content to export
        title: Document title
        subtitle: Optional subtitle
        content_type: Type of content (article, whitepaper, executive-brief, blog)
    """
    logger.info(f"[export_to_word_with_metadata] Starting export. Title: {title[:50]}, Content length: {len(content)}")
    
    try:
        # Load PwC template
        if os.path.exists(PWC_TEMPLATE_PATH):
            doc = Document(PWC_TEMPLATE_PATH)
            logger.info(f"Loaded PwC template from: {PWC_TEMPLATE_PATH}")
        else:
            logger.warning(f"PwC template not found at {PWC_TEMPLATE_PATH}, using default formatting")
            doc = Document()
    except Exception as e:
        logger.warning(f"Failed to load PwC template: {e}, using default formatting")
        doc = Document()
    
    # Check if template has proper structure (Title, Subtitle, page breaks)
    has_template_structure = (
        len(doc.paragraphs) > 2 and 
        doc.paragraphs[0].style.name == 'Title' and
        doc.paragraphs[1].style.name == 'Subtitle'
    )
    
    if has_template_structure:
        # Use template structure: update title and subtitle, remove page break paragraphs
        # Update title (paragraph 0) - clear runs and set text
        _set_paragraph_text_with_breaks(doc.paragraphs[0], title)
        
        # Reduce font size of title for better readability with longer titles
        for run in doc.paragraphs[0].runs:
            run.font.size = DocxPt(14)  # Reduced from 16pt to 14pt for better fit
        
        # Set paragraph alignment to center or left with word wrap enabled
        doc.paragraphs[0].alignment = None  # Use default alignment
        doc.paragraphs[0].paragraph_format.widow_control = True  # Better line breaking
        
        # Update subtitle (paragraph 1) with proper line breaks
        if subtitle and content_type:
            subtitle_text = f"{subtitle}\n{content_type.replace('-', ' ').title()}"
        elif subtitle:
            subtitle_text = subtitle
        elif content_type:
            subtitle_text = content_type.replace('-', ' ').title()
        else:
            subtitle_text = ''
        
        _set_paragraph_text_with_breaks(doc.paragraphs[1], subtitle_text)
        
        # Remove ALL template content after title and subtitle (including old TOC and page breaks)
        paragraphs_to_remove = list(doc.paragraphs[2:])
        for para in paragraphs_to_remove:
            p = para._element
            p.getparent().remove(p)

        # Add page break after subtitle
        _ensure_page_break_after_paragraph(doc.paragraphs[1])
        
        # Extract headings from content before adding it
        headings = _extract_headings_from_content(content)
        
        # Add Table of Contents on page 2
        if headings:
            _add_table_of_contents(doc, headings)
        
        # Add a page break before the generated content so it starts after the TOC page
        page_break_para = doc.add_paragraph()
        run = page_break_para.add_run()
        run.add_break(WD_BREAK.PAGE)
        
        # Add content after the page break
        _add_formatted_content(doc, content)
    else:
        # No template structure, clear everything and build from scratch
        for para in doc.paragraphs[:]:
            p = para._element
            p.getparent().remove(p)
        
        # Add title using Title style with sanitization
        sanitized_title = sanitize_text_for_word(title)
        title_para = doc.add_paragraph(sanitized_title, style='Title')
        
        # Add subtitle if provided
        if subtitle:
            sanitized_subtitle = sanitize_text_for_word(subtitle)
            subtitle_para = doc.add_paragraph(sanitized_subtitle, style='Subtitle')
        
        # Add content type if provided
        if content_type:
            sanitized_content_type = sanitize_text_for_word(f"Content Type: {content_type.replace('-', ' ').title()}")
            type_para = doc.add_paragraph(sanitized_content_type, style='Subtitle')
        
        # Add a blank line
        doc.add_paragraph()
        
        # Parse and add content with proper formatting
        _add_formatted_content(doc, content)
    
    buffer = io.BytesIO()
    try:
        doc.save(buffer)
    except UnicodeEncodeError as e:
        logger.error(f"Encoding error while saving document: {e}")
        raise Exception(f"Failed to save Word document due to encoding error: {str(e)}")
    except Exception as e:
        logger.error(f"Error saving Word document: {e}")
        raise Exception(f"Failed to save Word document: {str(e)}")
    
    buffer.seek(0)
    docx_bytes = buffer.getvalue()
    
    logger.info(f"[export_to_word_with_metadata] Document created, size before encoding fix: {len(docx_bytes)} bytes")
    
    # Apply encoding fix to ensure all Unicode characters are properly handled
    try:
        docx_bytes = _fix_docx_encoding(docx_bytes)
        logger.info(f"[export_to_word_with_metadata] Encoding fix applied, final size: {len(docx_bytes)} bytes")
    except Exception as e:
        logger.error(f"[export_to_word_with_metadata] Error during encoding fix: {e}")
        # Continue anyway - the document might still be valid
    
    logger.info(f"[export_to_word_with_metadata] Export completed successfully")
    return docx_bytes

def export_to_text(content: str) -> bytes:
    """Export content to plain text format"""
    return content.encode('utf-8')
